export const EyeIcon = ({ className }: { className?: string }) => {
  return (
    <svg
      width="25"
      height="25"
      viewBox="0 0 25 25"
      fill="none"
      className={className}
    >
      <path
        d="M15.1543 12.6244C15.1543 14.2813 13.8112 15.6244 12.1543 15.6244C10.4975 15.6244 9.1543 14.2813 9.1543 12.6244C9.1543 10.9675 10.4975 9.62439 12.1543 9.62439C13.8112 9.62439 15.1543 10.9675 15.1543 12.6244Z"
        stroke="#F7F6F1"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.1548 5.62439C7.67711 5.62439 3.88683 8.56727 2.61255 12.6244C3.88681 16.6815 7.67711 19.6244 12.1548 19.6244C16.6324 19.6244 20.4227 16.6815 21.697 12.6244C20.4227 8.5673 16.6324 5.62439 12.1548 5.62439Z"
        stroke="#F7F6F1"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}
