import React from 'react'

export const DollarIcon = (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width="25" height="25" viewBox="0 0 25 25" fill="none" {...props}>
      <g clipPath="url(#clip0_295_2251)">
        <path
          d="M8.55713 14.8978C8.55713 16.1865 9.6018 17.2312 10.8905 17.2312H13.0571C14.4378 17.2312 15.5571 16.1119 15.5571 14.7312C15.5571 13.3505 14.4378 12.2312 13.0571 12.2312H11.0571C9.67642 12.2312 8.55713 11.1119 8.55713 9.73117C8.55713 8.35046 9.67642 7.23117 11.0571 7.23117H13.2238C14.5125 7.23117 15.5571 8.27584 15.5571 9.5645M12.0571 5.73117V7.23117M12.0571 17.2312V18.7312M22.0571 12.2312C22.0571 17.754 17.58 22.2312 12.0571 22.2312C6.53428 22.2312 2.05713 17.754 2.05713 12.2312C2.05713 6.70832 6.53428 2.23117 12.0571 2.23117C17.58 2.23117 22.0571 6.70832 22.0571 12.2312Z"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_295_2251">
          <rect
            width="24"
            height="24"
            fill="white"
            transform="translate(0.0571289 0.0539856)"
          />
        </clipPath>
      </defs>
    </svg>
  )
}
