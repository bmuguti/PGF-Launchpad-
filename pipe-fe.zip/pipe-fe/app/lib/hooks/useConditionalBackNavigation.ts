import { useRouter } from 'next/navigation'

export const useConditionalBackNavigation = (fallbackUrl: string) => {
  const router = useRouter()

  const navigateBackOrFallback = () => {
    if (window.history.length > 2) {
      router.back()
    } else {
      router.push(fallbackUrl)
    }
  }

  return navigateBackOrFallback
}
