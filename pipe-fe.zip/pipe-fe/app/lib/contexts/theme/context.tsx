'use client'

import { createContext } from 'react'

interface IThemeContext {
  theme: 'dark' | 'light'
  toggleTheme: () => void
}

export const ThemeContext = createContext<IThemeContext>({
  theme: 'light',
  toggleTheme: () => {},
})
