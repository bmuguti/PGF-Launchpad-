'use client'
import { createContext } from 'react'

type IModalContext = {
  openModal: () => void
  closeModal: () => void
  open: boolean
}

export const ModalContext = createContext<IModalContext>({
  openModal: () => null,
  closeModal: () => null,
  open: false,
} as IModalContext)

ModalContext.displayName = 'ModalContext'
