'use client'

import React, { useState } from 'react'

import { ModalContext } from './context'

interface IModalProvider {
  children: React.ReactNode
}

export const ModalProvider = ({ children }: IModalProvider) => {
  const [open, setOpen] = useState(false)

  const openModal = () => setOpen(true)
  const closeModal = () => setOpen(false)

  return (
    <ModalContext.Provider value={{ openModal, closeModal, open }}>
      {children}
    </ModalContext.Provider>
  )
}
