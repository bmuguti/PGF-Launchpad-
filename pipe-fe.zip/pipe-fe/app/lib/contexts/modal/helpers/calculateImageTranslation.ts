export const calculateImageTranslation = (imagesLength: number) => {
  switch (imagesLength) {
    case 2:
      return 240
    case 3:
      return 165
    case 4:
      return 110
    case 5:
      return 81
    case 6:
      return 65
    case 7:
      return 54
    case 8:
      return 46
    case 9:
      return 41
    case 10:
      return 36
    case 11:
      return 32
    case 12:
      return 30
    case 13:
      return 27
    case 14:
      return 25
    case 15:
      return 24
    default:
      return 36
  }
}
