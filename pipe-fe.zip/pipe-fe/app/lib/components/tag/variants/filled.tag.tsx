import React from 'react'
import { twMerge } from 'tailwind-merge'

type TagProps = {
  children: React.ReactNode
  className?: string
} & React.HTMLAttributes<HTMLSpanElement>

export const FilledTag = ({ children, className, ...props }: TagProps) => {
  return (
    <span
      className={twMerge(
        'bg-[#E0FF01] px-[7px] py-[3px] text-xs rounded-[100px] font-bold text-black',
        className
      )}
      {...props}
    >
      {children}
    </span>
  )
}
