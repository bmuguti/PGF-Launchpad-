import React from 'react'
import { twMerge } from 'tailwind-merge'

type TagProps = {
  children: React.ReactNode
  className?: string
} & React.HTMLAttributes<HTMLSpanElement>

export const OutlineTag = ({ children, className, ...props }: TagProps) => {
  return (
    <span
      className={twMerge(
        'border border-[#E0FF01] bg-black px-[7px] py-[3px] text-xs rounded-[100px] font-bold',
        className
      )}
      {...props}
    >
      {children}
    </span>
  )
}
