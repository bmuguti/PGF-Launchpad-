import React from 'react'

import { FilledTag } from './variants/filled.tag'
import { OutlineTag } from './variants/outline.tag'

type TagProps = {
  variant?: 'filled' | 'outline'
  children: React.ReactNode
} & React.HTMLAttributes<HTMLSpanElement>

export const Tag = ({ variant, children, ...props }: TagProps) => {
  switch (variant) {
    case 'outline':
      return <OutlineTag {...props}>{children}</OutlineTag>
    case 'filled':
      return <FilledTag {...props}>{children}</FilledTag>
    default:
      return <FilledTag {...props}>{children}</FilledTag>
  }
}
