import React from 'react'

import { Footer } from '@/lib/components/footer'
import Header from '@/lib/components/header'

export const Layout = ({ children }: { children?: React.ReactNode }) => {
  return (
    <div className="flex flex-col min-h-screen bg-[#F7F6F1] dark:bg-black overflow-x-hidden">
      <Header />
      <div className="p-[30px] tablet:py-[60px] tablet:px-[10%] flex-grow">
        {children}
      </div>
      <Footer />
    </div>
  )
}
