'use client'

export const Icons = () => {
  return (
    <div className="flex flex-row h- items-center gap-x-6 text-xl">
      <i
        className="fa-brands fa-square-x-twitter cursor-pointer"
        onClick={() => {
          window.open('https://twitter.com/thepipegdao', '_blank')
        }}
      />
      <i
        className="fa-brands fa-linkedin cursor-pointer"
        onClick={() => {
          window.open(
            'https://www.linkedin.com/showcase/the-pipe-gdao',
            '_blank'
          )
        }}
      />
      <i
        className="fa-brands fa-facebook cursor-pointer"
        onClick={() => {
          window.open('facebook.com/thepipegdao', '_blank')
        }}
      />
      <i
        className="fa-brands fa-instagram cursor-pointer"
        onClick={() => {
          window.open(
            'https://instagram.com/thepipegdao?igshid=NGVhN2U2NjQ0Yg%3D%3D&utm_source=qr',
            '_blank'
          )
        }}
      />
      <i
        className="fa-brands fa-medium cursor-pointer"
        onClick={() => {
          window.open('https://medium.com/@thepipegdao', '_blank')
        }}
      />
      <i
        className="fa-brands fa-discord cursor-pointer"
        onClick={() => {
          window.open('https://discord.gg/K2CqFH5VWd', '_blank')
        }}
      />
    </div>
  )
}
