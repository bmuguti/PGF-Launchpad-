import { Icons } from './icons'

export const Footer = () => {
  return (
    <footer className="flex flex-col gap-y-[30px] py-[27px] px-[30px] tablet:flex-row bg-[#F8F4E9] dark:bg-black text-black dark:text-white dark:border-t dark:border-t-[#eae7e717] tablet:px-[10%] justify-between items-center">
      <span className="font-normal">
        © {new Date().getFullYear()} PipeDAO. All rights reserved
      </span>
      <Icons />
    </footer>
  )
}
