'use client'

import { Theme, ToastContainer } from 'react-toastify'

import { useTheme } from '@/lib/contexts/theme'

export const CustomToastProvider = () => {
  const { theme } = useTheme()
  return (
    <>
      <ToastContainer theme={theme as Theme | undefined} />
    </>
  )
}
