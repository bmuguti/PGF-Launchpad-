import { twMerge } from 'tailwind-merge'

export const Divider = ({ className }: { className?: string }) => {
  return (
    <div
      className={twMerge(
        'my-9 w-full h-[1px] bg-[#DDD3C6] dark:bg-[#ddd3c64d]',
        className
      )}
    />
  )
}
