import { twMerge } from 'tailwind-merge'

import { ProgressBar } from '../progress-bar'

interface TimeLineProps {
  className?: string
  progress: number
}

const statuses = [
  'Preparing',
  'Disclosing',
  'Being Reviewed',
  'Reporting',
  'Decision',
]

export const Timeline = ({ progress, className }: TimeLineProps) => {
  return (
    <div className={twMerge('flex flex-col', className)}>
      <h2 className="font-bold text-black dark:text-white">Project Timeline</h2>
      <ProgressBar progress={progress} className="mt-2" />
      <div className="w-full mt-4 flex flex-row justify-between">
        {statuses.map((status, index) => (
          <div key={index}>
            <p className="text-[11px] tablet:text-[13px] font-bold text-black dark:text-white">
              {status}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
