import { Project } from '@/lib/types/project'

export const calculateProgress = (status: Project['status']) => {
  switch (status) {
    case 'preparing':
      return 7.5
    case 'disclosing':
      return 30
    case 'being reviewed':
      return 55
    case 'reporting':
      return 78
    case 'triage':
      return 100
    default:
      return 0
  }
}
