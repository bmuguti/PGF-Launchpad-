'use client'

import { motion } from 'framer-motion'

import { fadeInUp, staggerContainer, staggerItem } from '@/lib/animations/variants'
import { Button } from '../button'
import InvestedAmount from './investedAmount'
import RaisedAmount from './raisedAmount'

export default function PageOverview() {
  return (
    <motion.div 
      className="flex flex-col"
      initial="hidden"
      animate="visible"
      variants={staggerContainer}
    >
      <motion.h1 
        className="my-3 text-[31px] text-center tablet:text-start font-bold text-black dark:text-white"
        variants={fadeInUp}
      >
        A University RWA IP Launchpad
      </motion.h1>
      <motion.span 
        className="text-[#373A3D] dark:text-white text-center tablet:text-start tablet:w-1/2"
        variants={fadeInUp}
      >
        Bridging the gap between University IP Real World Assets and web3
        capital, the PGF Launchpad connects EU University lab innovators
        directly with retail investors on the blockchain.
      </motion.span>
      <motion.div 
        className="mt-11 flex flex-col gap-y-[30px] tablet:gap-y-0 tablet:flex-row gap-x-9"
        variants={staggerItem}
      >
        <RaisedAmount />
        <InvestedAmount />
        <motion.div 
          className="flex flex-col gap-y-[14px] mt-[30px] w-full tablet:ml-auto tablet:w-[30%] tablet:max-w-[350px] tablet:mt-0 tablet:self-end"
          variants={staggerItem}
        >
          <Button variant="getInvolved" className="w-full" />
          <Button variant="invest" className="w-full" />
        </motion.div>
      </motion.div>
    </motion.div>
  )
}
