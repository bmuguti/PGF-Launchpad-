'use client'

import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { useAccount } from 'wagmi'

import { LoadingSpinner } from '../loading-spinner'
import { ProgressBar } from '../progress-bar'

export default function InvestedAmount() {
  const { address } = useAccount()
  const [uerInvestedAmount, setUserInvestedAmount] = useState<number | null>(
    null
  )

  useEffect(() => {
    if (!address) return setUserInvestedAmount(0)
    fetch(`api/get-user-invested-amount/${address}`)
      .then((res) => res.json())
      .then((res) => {
        if (!res.success) {
          setUserInvestedAmount(0)
          return toast.error("Error while fetching user's invested amount")
        }
        setUserInvestedAmount(res.data.userInvestedAmount)
      })
  }, [address])

  if (uerInvestedAmount === null) {
    return (
      <div className="flex h-full items-center justify-center tablet:ml-10">
        <LoadingSpinner />
      </div>
    )
  }

  return (
    <div className="flex flex-col">
      <span className="text-[31px] font-bold text-center tablet:text-start text-black dark:text-white">
        ${uerInvestedAmount}
      </span>
      <span className="text-center tablet:text-start text-black dark:text-white">
        Your Amount Invested{' '}
      </span>
      <ProgressBar progress={20} className="mt-2" />
    </div>
  )
}
