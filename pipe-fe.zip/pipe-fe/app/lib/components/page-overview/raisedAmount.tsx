'use client'

import { useQuery } from '@tanstack/react-query'
import { getTotalInvestedAmount } from '@/lib/helpers/fetchInvestmentContract'
import { formatNumber } from '@/lib/helpers/formatNumber'
import { getTargetRaise } from '@/lib/services/api'
import { ProgressBar } from '../progress-bar'

export default function RaisedAmount() {
  const { data: totalInvestedAmount = 0, isLoading: loadingInvested } = useQuery({
    queryKey: ['totalInvestedAmount'],
    queryFn: getTotalInvestedAmount,
    staleTime: 60 * 1000, // 1 minute
    refetchOnWindowFocus: false,
  })

  const { data: totalRaise = 0, isLoading: loadingRaise } = useQuery({
    queryKey: ['totalRaise'],
    queryFn: getTargetRaise,
    staleTime: 60 * 1000,
    refetchOnWindowFocus: false,
  })

  if (loadingInvested || loadingRaise) {
    return <div>Loading...</div>
  }

  // Calculate progress
  let progress = (totalInvestedAmount / totalRaise) * 100
  let progressDisplay =
    progress > 0 && progress < 0.01 ? '0.00%' : `${progress.toFixed(2)}%`
  progress = progress < 0.01 ? 0.01 : progress

  return (
    <div className="flex flex-col">
      <span className="text-[31px] text-center tablet:text-start font-bold text-black dark:text-white">
        ${totalInvestedAmount.toFixed(2) || 0}
      </span>
      <span className="text-center tablet:text-start text-black dark:text-white">
        {progressDisplay} raised of ${formatNumber(totalRaise)} max goal
      </span>
      <ProgressBar progress={progress} className="mt-2" />
    </div>
  )
}
