'use client'
import { usePathname, useSearchParams } from 'next/navigation'
import { Router } from 'next/router'
import { useEffect } from 'react'

if (!process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID) {
  throw new Error('Missing NEXT_PUBLIC_FACEBOOK_PIXEL_ID environment variable.')
}

export default function FacebookPixelEvents() {
  const pathname = usePathname()
  const searchParams = useSearchParams()

  useEffect(() => {
    import('react-facebook-pixel')
      .then((x) => x.default)
      .then((ReactPixel) => {
        ReactPixel.init(process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID!, undefined, {
          autoConfig: true,
          debug: process.env.NODE_ENV === 'development',
        })
        ReactPixel.pageView()

        Router.events.on('routeChangeComplete', () => {
          ReactPixel.pageView()
        })
      })
  }, [pathname, searchParams])

  return null
}
