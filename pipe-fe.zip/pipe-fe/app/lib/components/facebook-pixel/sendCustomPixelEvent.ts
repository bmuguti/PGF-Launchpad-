'use client'
import { useEffect } from 'react'

export default function CustomFacebookPixelEvent({
  eventName,
  eventParams,
}: {
  eventName: string
  eventParams?: Record<string, unknown>
}) {
  useEffect(() => {
    if (!eventName) return

    import('react-facebook-pixel')
      .then((x) => x.default)
      .then((ReactPixel) => {
        ReactPixel.init(process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID!, undefined, {
          autoConfig: true,
          debug: process.env.NODE_ENV === 'development',
        })
        ReactPixel.trackCustom(eventName, eventParams)
      })
  }, [eventName, eventParams]) // Add eventParams as a dependency if needed

  return null
}
