import { TokenInfo } from '@/lib/types/investment-info'

export const AssetSelectMenu = ({
  tokens,
  selectedToken,
  onChange,
}: {
  tokens: TokenInfo[]
  selectedToken: string
  onChange: (value: string) => void
}) => {
  return (
    <div>
      <label
        htmlFor="asset"
        className="block text-sm font-medium leading-6 text-gray-900 dark:text-white"
      >
        Asset
      </label>
      <select
        id="asset"
        name="asset"
        className="mt-2 block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-indigo-600 sm:text-sm sm:leading-6"
        value={selectedToken}
        onChange={(e) => onChange(e.target.value)}
      >
        {tokens.map((token) => (
          <option key={token.name} value={token.name}>
            {token.name}
          </option>
        ))}
      </select>
    </div>
  )
}
