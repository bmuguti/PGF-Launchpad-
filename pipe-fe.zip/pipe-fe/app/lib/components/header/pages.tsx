import Link from 'next/link'

import { ROUTES } from '@/lib/constants/routes'

import { NavLink } from '../nav-link'

export default function Pages() {
  return (
    <div className="flex items-center gap-x-10">
      <NavLink href={ROUTES.STAKING}>Staking</NavLink>
      <NavLink href={ROUTES.LAUNCHPAD}>Launchpad</NavLink>
      <NavLink href={ROUTES.FAQS}>{"FAQ's"}</NavLink>
      <Link
        href="https://discord.gg/K2CqFH5VWd"
        className="font-normal text-sm text-black dark:text-white"
        rel="noopener noreferrer"
      >
        Discord
      </Link>
      <Link
        href="https://www.thepipegdao.io/"
        className="font-normal text-sm text-black dark:text-white"
        rel="noopener noreferrer"
      >
        Visit Website
      </Link>
    </div>
  )
}
