'use client'
import { Dialog } from '@headlessui/react'
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline'
import Link from 'next/link'
import { useState } from 'react'
import { twMerge } from 'tailwind-merge'
import { useAccount } from 'wagmi'

import { ConnectWalletButton } from '@/lib/components/connect-wallet-button'
import { ROUTES } from '@/lib/constants/routes'

// import { ConnectWalletButton } from '../connect-wallet-button'
import Logo from '../logo'
import { NavLink } from '../nav-link'
import { ThemeToggle } from '../theme-toggle'
import { Account } from '../wallets/account'
import { WalletOptions } from '../wallets/walletOptions'
import Pages from './pages'

function ConnectWallet() {
  const { isConnected } = useAccount()
  if (isConnected) return <Account />
  return <WalletOptions />
}

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header
      className={twMerge(
        'bg-[#F8F4E9] pb-[18px] pt-[60px] px-[20px] tablet:py-[18px] flex justify-between items-center border-b border-b-[#EAE7E7] dark:bg-black dark:border-b dark:border-b-[#eae7e717] tablet:px-[10%] desktop:px-[5%]'
      )}
    >
      <button
        type="button"
        className="tablet:hidden block rounded-md p-2.5 text-gray-700 dark:text-white z-10"
        onClick={() => setMobileMenuOpen(true)}
      >
        <span className="sr-only">Open menu</span>
        <Bars3Icon className="h-6 w-6" aria-hidden="true" />
      </button>

      <div className="-ml-[44px] tablet:ml-0 flex-1 tablet:min-w-fit flex justify-center tablet:block cursor-pointer">
        <Logo />
      </div>
      <div className="hidden tablet:flex flex-1 items-center justify-center px-4">
        <Pages />
        <ThemeToggle className="hidden tablet:block" />
      </div>
      <div className="hidden tablet:flex flex-1 justify-end">
        {/*<ConnectWallet />*/}
        <ConnectWalletButton />
      </div>
      <Dialog
        as="div"
        className="lg:hidden"
        open={mobileMenuOpen}
        onClose={setMobileMenuOpen}
      >
        <div className="fixed inset-0 z-10" />
        <Dialog.Panel className="fixed inset-y-0 right-0 z-10 w-full overflow-y-auto bg-[#F7F6F1] dark:bg-[#24272C] px-[30px] py-[70px]">
          <div className="flex items-center justify-between">
            <button
              type="button"
              className="rounded-md text-gray-700 dark:text-white"
              onClick={() => setMobileMenuOpen(false)}
            >
              <span className="sr-only">Close menu</span>
              <XMarkIcon className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>
          <div className="mt-6 flow-root">
            <div className="divide-y divide-gray-500/10">
              <div className="space-y-2 py-6">
                <div className="ml-1 flex flex-col gap-y-10">
                  <div
                    onClick={() => {
                      setMobileMenuOpen(false)
                    }}
                  >
                    <NavLink href={ROUTES.STAKING}>Staking</NavLink>
                  </div>
                  <div
                    onClick={() => {
                      setMobileMenuOpen(false)
                    }}
                  >
                    <NavLink href={ROUTES.LAUNCHPAD}>Launchpad</NavLink>
                  </div>
                  <div onClick={() => setMobileMenuOpen(false)}>
                    <NavLink href={ROUTES.FAQS}>{"FAQ's"}</NavLink>
                  </div>
                  <Link
                    href="https://discord.gg/K2CqFH5VWd"
                    className="font-normal text-sm text-black dark:text-white"
                    rel="noopener noreferrer"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Discord
                  </Link>
                  <Link
                    href="https://www.thepipegdao.io/"
                    className="font-normal text-sm text-black dark:text-white"
                    rel="noopener noreferrer"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Visit Website
                  </Link>
                  <ThemeToggle />
                </div>
              </div>
              <div className="py-6 w-full">
                <ConnectWalletButton />
              </div>
            </div>
          </div>
        </Dialog.Panel>
      </Dialog>
    </header>
  )
}
