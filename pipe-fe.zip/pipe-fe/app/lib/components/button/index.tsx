import React from 'react'

import { BackButton } from './variants/back.button'
import { DarkButton } from './variants/dark.button'
import { GetInvolvedButton } from './variants/getInvolved.button'
import { InvestButton } from './variants/invest.button'
import { LightButton } from './variants/light.button'
import { OutlineButton } from './variants/outline.button'

type ButtonProps = {
  children?: React.ReactNode
  className?: string
  disabled?: boolean
  variant?: 'dark' | 'outline' | 'back' | 'invest' | 'getInvolved'
  onClick?: () => void
}

export const Button = ({ children, variant, ...props }: ButtonProps) => {
  switch (variant) {
    case 'back':
      return <BackButton {...props}>{children}</BackButton>
    case 'outline':
      return <OutlineButton {...props}>{children}</OutlineButton>
    case 'getInvolved':
      return <GetInvolvedButton {...props}>{children}</GetInvolvedButton>
    case 'dark':
      return <DarkButton {...props}>{children}</DarkButton>
    case 'invest':
      return <InvestButton {...props}>{children}</InvestButton>
    default:
      return <LightButton {...props}>{children}</LightButton>
  }
}
