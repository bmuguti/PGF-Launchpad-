'use client'
import { twMerge } from 'tailwind-merge'

import { ROUTES } from '@/lib/constants/routes'
import { useConditionalBackNavigation } from '@/lib/hooks/useConditionalBackNavigation'

type ButtonProps = {
  className?: string
}

export const BackButton = ({ className, ...props }: ButtonProps) => {
  const navigate = useConditionalBackNavigation(ROUTES.LAUNCHPAD)

  return (
    <button
      className={twMerge(
        'flex items-center justify-center gap-x-3 font-bold text-black dark:text-white',
        className
      )}
      onClick={() => navigate()}
      {...props}
    >
      <svg
        width="20"
        height="17"
        viewBox="0 0 20 17"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M1.44922 9.73828L0.460938 8.75L1.44922 7.80469L7.63672 1.61719L8.625 0.628906L10.5586 2.5625L9.57031 3.55078L5.74609 7.375H18.25H19.625V10.125H18.25H5.74609L9.57031 13.9922L10.5586 14.9375L8.625 16.9141L7.63672 15.9258L1.44922 9.73828Z"
          fill="currentColor"
        />
      </svg>
      Back
    </button>
  )
}
