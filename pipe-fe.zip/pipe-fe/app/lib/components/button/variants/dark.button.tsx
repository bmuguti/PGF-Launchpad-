import React from 'react'
import { twMerge } from 'tailwind-merge'

type DarkButtonProps = {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export const DarkButton = ({
  children,
  className,
  onClick,
}: DarkButtonProps) => {
  return (
    <button
      onClick={onClick}
      className={twMerge(
        'px-2 py-1 w-[350px] h-[50px] bg-[#24272C] text-white border border-[#EAE7E7] rounded-md flex flex-row justify-center items-center gap-x-2 font-bold',
        className
      )}
    >
      {children}
    </button>
  )
}
