import { motion } from 'framer-motion'
import React from 'react'
import { twMerge } from 'tailwind-merge'

type OutlineButtonProps = {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export const OutlineButton = ({
  children,
  className,
  onClick,
}: OutlineButtonProps) => {
  return (
    <motion.button
      onClick={onClick}
      className={twMerge(
        'px-2 py-1 w-[350px] h-[50px] bg-transparent border border-[#99A838] rounded-md flex flex-row justify-center items-center gap-x-2 font-bold text-[#24272C] dark:text-white',
        className
      )}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
    >
      {children}
    </motion.button>
  )
}
