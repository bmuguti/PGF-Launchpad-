'use client'

import { motion } from 'framer-motion'
import React from 'react'
import { twMerge } from 'tailwind-merge'

import { AtomIcon } from '@/lib/assets/icons/atom'

type GetInvolvedButtonProps = {
  children: React.ReactNode
  className?: string
}

export const GetInvolvedButton = ({
  children,
  className,
}: GetInvolvedButtonProps) => {
  return (
    <motion.button
      onClick={() => {
        window.open('https://www.labtoipo.com/join-us', '_blank')
      }}
      className={twMerge(
        'px-2 py-1 w-[350px] h-[50px] bg-white dark:bg-[#24272C] border border-[#EAE7E7] dark:border-[#30343A] rounded-md flex flex-row justify-center items-center gap-x-2 font-bold text-[#24272C] dark:text-white',
        className
      )}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
    >
      <AtomIcon />
      <span>Get Involved</span>
      {children}
    </motion.button>
  )
}
