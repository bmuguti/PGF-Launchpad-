import React from 'react'
import { twMerge } from 'tailwind-merge'

type LightButtonProps = {
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export const LightButton = ({
  children,
  className,
  onClick,
}: LightButtonProps) => {
  return (
    <button
      onClick={onClick}
      className={twMerge(
        'px-2 py-1 w-[350px] h-[50px] bg-white dark:bg-[#24272C] border border-[#EAE7E7] dark:border-[#30343A] rounded-md flex flex-row justify-center items-center gap-x-2 font-bold text-[#24272C] dark:text-white',
        className
      )}
    >
      {children}
    </button>
  )
}
