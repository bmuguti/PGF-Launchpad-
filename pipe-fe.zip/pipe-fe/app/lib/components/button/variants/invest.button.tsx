'use client'

import { motion } from 'framer-motion'
import { toast } from 'react-toastify'
import { twMerge } from 'tailwind-merge'
import { useAccount } from 'wagmi'

import { CoinsHandIcon } from '@/lib/assets/icons/coins-hand'
import { useModal } from '@/lib/contexts/modal'

type InvestButtonProps = {
  className?: string
  disabled?: boolean
}

export const InvestButton = ({ className, disabled }: InvestButtonProps) => {
  const { openModal } = useModal()
  const { isConnected, isConnecting } = useAccount()

  return (
    <motion.button
      onClick={() => {
        if (!isConnected) return toast.error('Please connect your wallet')
        openModal()
      }}
      disabled={disabled}
      className={twMerge(
        'px-2 py-1 w-[350px] h-[50px] bg-[#24272C] text-white border border-[#EAE7E7] rounded-md flex flex-row justify-center items-center gap-x-2 font-bold',
        (disabled || (!isConnected && !isConnecting)) &&
          'opacity-70 cursor-not-allowed',
        className
      )}
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      transition={{ duration: 0.2 }}
    >
      <CoinsHandIcon />
      <span>Invest</span>
    </motion.button>
  )
}
