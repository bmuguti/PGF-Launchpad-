'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'

import { scaleIn } from '@/lib/animations/variants'
import { EyeIcon } from '@/lib/assets/icons/eye'
import { Button } from '@/lib/components/button'
import { ImageWrapper } from '@/lib/components/image-wrapper'
import { Tag } from '@/lib/components/tag'
import { ROUTES } from '@/lib/constants/routes'
import { useTheme } from '@/lib/contexts/theme'
import { normalizeTitleForURL } from '@/lib/helpers/normalizeTitleForURL'
import { Project } from '@/lib/types/project'

type ProjectCardProps = {
  project: Project
}

export const ProjectCard = ({ project }: ProjectCardProps) => {
  const { theme } = useTheme()
  
  if (!project.uid) return <></>
  
  const lightGradient = 'linear-gradient(273deg, rgba(248, 244, 233, 0.9) -16.07%, rgba(234, 231, 231, 0.8) 53.76%)'
  const darkGradient = 'linear-gradient(273deg, rgba(89, 70, 40, 0.72) -16.07%, #25272C 53.76%)'
  
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.4 }}
    >
      <Link
        href={ROUTES.PROJECT_DETAILS.replace(
          ':title',
          normalizeTitleForURL(project.seoTitle || project.uid)
        )}
        className={
          'p-4 gap-x-9 flex flex-col tablet:flex-row items-center rounded-[20px] block'
        }
        style={{
          background: theme === 'dark' ? darkGradient : lightGradient,
        }}
      >
      <ImageWrapper
        alt={project.title}
        src={project.image}
        width={240}
        height={224}
        className="flex-shrink-0"
      />

      <div className="flex flex-col">
        <div className="flex flex-row gap-3 mt-[30px] tablet:mt-0 flex-wrap">
          {project.keywords.map((tag) => (
            <Tag key={tag}>
              <span>{tag}</span>
            </Tag>
          ))}
        </div>
        <h1 className="my-3 text-[25px] font-bold text-black dark:text-[#F7F6F1]">
          {project.seoTitle}
        </h1>
        <p className="text-black dark:text-white text-[13px] font-normal">
          {project.seoDescription}
        </p>
        <Button variant="outline" className="w-full tablet:w-[182px] mt-5">
          <EyeIcon />
          <span className="text-black dark:text-[#F7F6F1]">View Project</span>
        </Button>
      </div>
    </Link>
    </motion.div>
  )
}
