'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import React from 'react'
import { twMerge } from 'tailwind-merge'

interface ICustomNavLink {
  href: string
  children: React.ReactNode
}

export const NavLink = ({ href, children }: ICustomNavLink) => {
  const pathname = usePathname()
  const isActive = pathname === href

  const linkClassName = twMerge(
    'font-normal text-sm text-black dark:text-white',
    isActive && 'font-bold'
  )

  return (
    <Link href={href} className={linkClassName}>
      {children}
    </Link>
  )
}
