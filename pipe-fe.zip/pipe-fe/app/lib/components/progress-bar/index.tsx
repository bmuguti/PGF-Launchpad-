import { twMerge } from 'tailwind-merge'

type ProgressBarProps = {
  progress: number
  className?: string
}

export const ProgressBar = ({ progress, className }: ProgressBarProps) => {
  return (
    <div
      className={twMerge(
        'relative w-full h-3 bg-gray-800 dark:bg-[#F7F6F1] rounded-full overflow-hidden border-none',
        className
      )}
    >
      <div
        style={{ width: `${progress}%` }}
        className="absolute h-full bg-[#E0FF01] rounded-full border-none"
      ></div>
    </div>
  )
}
