import { useConnect } from 'wagmi'

export function WalletOptions() {
  const { connectors, connect } = useConnect()

  const walletConnectConnector = connectors.find(
    (connector) => connector.name === 'WalletConnect'
  )

  const metamaskConnector = connectors.find(
    (connector) => connector.name === 'Injected'
  )

  return (
    <div className="flex gap-x-2 text-white">
      {metamaskConnector && (
        <button
          key={metamaskConnector.uid}
          className="text-gray-700 dark:text-white"
          onClick={() => connect({ connector: metamaskConnector })}
        >
          Metamask
        </button>
      )}
      {walletConnectConnector && (
        <button
          key={walletConnectConnector.uid}
          className="text-gray-700 dark:text-white"
          onClick={() => connect({ connector: walletConnectConnector })}
        >
          Wallet Connect
        </button>
      )}
    </div>
  )
}
