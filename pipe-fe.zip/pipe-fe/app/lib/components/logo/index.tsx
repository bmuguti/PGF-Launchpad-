'use client'

import { useRouter } from 'next/navigation'

import { LogoIcon } from '@/lib/assets/icons/logo'
import { ROUTES } from '@/lib/constants/routes'

export default function Logo() {
  const router = useRouter()
  return (
    <div
      className="bg-[#24272C] dark:border dark:border-[#30343A] flex gap-x-2 h-[36px] w-fit items-center justify-center rounded-[20px] px-3 py-2"
      onClick={() => {
        router.push(ROUTES.LAUNCHPAD)
        // window.location.href = ROUTES.LAUNCHPAD
      }}
    >
      <LogoIcon />
      <span className="font-extrabold text-xs font-jakarta text-white">
        PIPE gDAO
      </span>
    </div>
  )
}
