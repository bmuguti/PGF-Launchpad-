import { useMemo } from 'react'

import assetsConfig from '../../config/assets.json'

export const NetworkSelectMenu = ({
  onChange,
  defaultValue = 1,
}: {
  // eslint-disable-next-line no-unused-vars
  onChange: (value: number) => void
  defaultValue?: number
}) => {
  const options = useMemo(() => {
    return Object.entries(assetsConfig)
      .filter(([_, asset]) => asset.investmentContractAddress !== '')
      .sort((a, b) => a[1].name.localeCompare(b[1].name)) // Sorting by name
      .map(([key, asset]) => (
        <option key={key} value={parseInt(key)}>
          {asset.name}
        </option>
      ))
  }, [assetsConfig])

  return (
    <div className="my-4">
      <label
        htmlFor="network"
        className="block text-sm font-medium leading-6 text-gray-900 dark:text-white"
      >
        Network
      </label>
      <select
        id="network"
        name="network"
        className="mt-2 block w-full rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-indigo-600 sm:text-sm sm:leading-6"
        defaultValue={defaultValue}
        onChange={(e) => onChange(parseInt(e.target.value))}
      >
        {options}
      </select>
    </div>
  )
}
