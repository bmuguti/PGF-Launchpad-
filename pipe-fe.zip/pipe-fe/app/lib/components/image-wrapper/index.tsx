'use client'

import Image, { ImageProps } from 'next/image'
import { twMerge } from 'tailwind-merge'

interface ImageWrapperProps extends ImageProps {
  src: string
  alt: string
}

export const ImageWrapper = ({ src, alt, ...props }: ImageWrapperProps) => {
  return (
    <div
      className={twMerge(
        'relative w-[240px] h-[224px] rounded-[20px] overflow-hidden bg-gray-200',
        props.className
      )}
    >
      <Image
        src={src}
        alt={alt}
        width={240}
        height={224}
        className="absolute inset-0 w-full h-full object-cover"
        onError={(e) => (e.currentTarget.style.display = 'none')}
        {...props}
      />
    </div>
  )
}
