'use client'
import Script from 'next/script'

if (!process.env.NEXT_PUBLIC_FACEBOOK_PIXEL_ID) {
  throw new Error('Missing NEXT_PUBLIC_FACEBOOK_PIXEL_ID environment variable.')
}

export default function GoogleAnalytics() {
  return (
    <>
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID}`}
      />
      <Script id="google-analytics">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID}');
        `}
      </Script>
    </>
  )
}
