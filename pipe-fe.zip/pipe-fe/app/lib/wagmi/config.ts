import { walletConnect } from '@wagmi/connectors'
import { injected } from '@wagmi/core'
import { cookieStorage, createConfig, createStorage, http } from 'wagmi'
import {
  arbitrum,
  avalanche,
  base,
  bsc,
  mainnet,
  optimism,
  polygon,
  Chain,
} from 'wagmi/chains'

if (!process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID)
  throw new Error(
    'Missing NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID environment variable.'
  )

const l1x: Chain = {
  id: 1066,
  name: 'L1X',
  nativeCurrency: {
    name: 'L1X',
    symbol: 'L1X',
    decimals: 18,
  },
  rpcUrls: {
    default: { http: ['https://v2-mainnet-rpc.l1x.foundation/'] },
    public: { http: ['https://v2-mainnet-rpc.l1x.foundation/'] },
  },
  blockExplorers: {
    default: { name: 'L1X Explorer', url: 'https://explorer.l1x.foundation/' },
  },
}

export const chains = [
  mainnet,
  bsc,
  avalanche,
  base,
  arbitrum,
  polygon,
  optimism,
  l1x,
] as const

export const storage = createStorage({
  storage: cookieStorage,
})

export const transports = {
  [mainnet.id]: http(),
  [bsc.id]: http(),
  [polygon.id]: http(),
  [arbitrum.id]: http(),
  [avalanche.id]: http(),
  [base.id]: http(),
  [optimism.id]: http(),
  [l1x.id]: http('https://v2-mainnet-rpc.l1x.foundation/'),
}

export const config = createConfig({
  chains,
  connectors: [
    injected(),
    walletConnect({
      projectId: process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID,
    }),
  ],
  ssr: true,
  storage,
  transports,
})
