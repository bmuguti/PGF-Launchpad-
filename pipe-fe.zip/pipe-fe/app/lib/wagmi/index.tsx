'use client'

import '@rainbow-me/rainbowkit/styles.css'

import { getDefaultConfig, RainbowKitProvider } from '@rainbow-me/rainbowkit'
import {
  coinbaseWallet,
  injectedWallet,
  metaMaskWallet,
  rainbowWallet,
  trustWallet,
  uniswapWallet,
  walletConnectWallet,
} from '@rainbow-me/rainbowkit/wallets'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import React from 'react'
import { type State, WagmiProvider } from 'wagmi'

import { chains, storage, transports } from './config'

const config = getDefaultConfig({
  appName: 'The PIPE gDAO',
  projectId: process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID!,
  chains,
  wallets: [
    {
      groupName: 'Recommended',
      wallets: [
        injectedWallet,
        metaMaskWallet,
        rainbowWallet,
        walletConnectWallet,
        uniswapWallet,
        trustWallet,
        coinbaseWallet,
      ],
    },
  ],
  ssr: true,
  storage,
  transports,
})
export { useAccount } from 'wagmi'

const queryClient = new QueryClient()

export function CustomWagmiProvider({
  children,
  initialState,
}: {
  children: React.JSX.Element
  initialState: State
}) {
  return (
    <WagmiProvider config={config} initialState={initialState}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider>{children}</RainbowKitProvider>
      </QueryClientProvider>
    </WagmiProvider>
  )
}
