import { ethers } from 'ethers'

import InvestmentInfo from '@/lib/config/assets.json'
// Use a compatible type for AssetInfo import
import { AssetInfo, TokenInfo } from '@/lib/types/investment-info'

const getRequestBody = (contractAddress: string) => {
  return {
    jsonrpc: '2.0',
    method: 'eth_call',
    params: [
      {
        to: contractAddress,
        // Function selector for the getInvestedAmount function
        data: '0x43214521',
      },
      'latest',
    ],
    id: 1,
  }
}

// Function to sum up results from all networks and all tokens
export async function getTotalInvestedAmount(): Promise<number> {
  try {
    const requests: Promise<any>[] = []
    Object.values(InvestmentInfo)
      .filter((info: any) => info.investmentContractAddress && info.investmentContractAddress !== '')
      .forEach((info: any) => {
        (info.tokens || []).forEach((token: TokenInfo) => {
          const request = new Promise((resolve, reject) => {
            fetch(info.RPC_URL, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(
                getRequestBody(info.investmentContractAddress)
              ),
            })
              .then((response) => response.json())
              .then((data) => {
                resolve({
                  data: data,
                  token: token,
                })
              })
              .catch((error) => {
                reject(error)
              })
          })
          requests.push(request)
        })
      })
    const responses = await Promise.all(requests).catch((error) => {
      console.error('Error fetching data from networks:', error)
      throw error
    })

    const totalInvestedAmount: number = responses.reduce(
      (
        acc: number,
        response: {
          data: any
          token: TokenInfo
        }
      ) => {
        // Defensive: skip if result is missing, not a string, or not a valid hex
        if (
          !response.data ||
          typeof response.data.result !== 'string' ||
          !/^0x[0-9a-fA-F]*$/.test(response.data.result) ||
          response.data.result === '0x'
        ) {
          return acc
        }
        const result = parseInt(response.data.result, 16)
        if (isNaN(result)) return acc
        const decimals = response.token.decimals
        const ethValue = parseFloat(
          ethers.formatUnits(result.toString(), decimals).toString()
        )
        return acc + ethValue
      },
      0
    )

    return parseFloat(totalInvestedAmount.toString())
  } catch (error) {
    console.error('Error fetching data from networks:', error)
    throw error
  }
}
