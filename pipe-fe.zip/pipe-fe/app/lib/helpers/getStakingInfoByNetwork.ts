// Based on the staking-assets.json file, this function returns the contract address for the given network and the asset
import { AssetInfo } from '@/lib/types/investment-info'

export const getStakingInfoByNetwork = (network: number): AssetInfo | undefined => {
  const stakingAssetsConfig = require('@/lib/config/staking-assets.json')
  return stakingAssetsConfig[network] as AssetInfo | undefined
}