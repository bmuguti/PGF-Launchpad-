export const truncateAddress = (address: string) => {
  const firstPart = address.slice(0, 6) // takes first 6 characters
  const lastPart = address.slice(-17) // takes last 6 characters
  return `${firstPart}...${lastPart}`
}
