import { ethers } from 'ethers'

import StakingInfo from '@/lib/config/staking-assets.json'
import { AssetInfo, TokenInfo } from '@/lib/types/investment-info'

const getRequestBody = (contractAddress: string) => {
  return {
    jsonrpc: '2.0',
    method: 'eth_call',
    params: [
      {
        to: contractAddress,
        // Function selector for the totalInvestedAmount function
        data: '0x43214521',
      },
      'latest',
    ],
    id: 1,
  }
}

// Function to get total staked amount from all staking contracts
export async function getTotalStakedAmount(): Promise<number> {
  try {
    const requests: Promise<any>[] = []
    Object.values(StakingInfo)
      .filter((info: any) => info.investmentContractAddress && info.investmentContractAddress !== '')
      .forEach((info: any) => {
        (info.tokens || []).forEach((token: TokenInfo) => {
          const request = new Promise((resolve, reject) => {
            fetch(info.RPC_URL, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(
                getRequestBody(info.investmentContractAddress)
              ),
            })
              .then((response) => response.json())
              .then((data) => {
                resolve({
                  data: data,
                  token: token,
                })
              })
              .catch((error) => {
                reject(error)
              })
          })
          requests.push(request)
        })
      })
    const responses = await Promise.all(requests).catch((error) => {
      console.error('Error fetching data from staking networks:', error)
      throw error
    })

    const totalStakedAmount: number = responses.reduce(
      (
        acc: number,
        response: {
          data: any
          token: TokenInfo
        }
      ) => {
        // Defensive: skip if result is missing, not a string, or not a valid hex
        if (
          !response.data ||
          typeof response.data.result !== 'string' ||
          !/^0x[0-9a-fA-F]*$/.test(response.data.result) ||
          response.data.result === '0x'
        ) {
          return acc
        }
        const result = parseInt(response.data.result, 16)
        if (isNaN(result)) return acc
        const decimals = response.token.decimals
        const ethValue = parseFloat(
          ethers.formatUnits(result.toString(), decimals).toString()
        )
        return acc + ethValue
      },
      0
    )

    return parseFloat(totalStakedAmount.toString())
  } catch (error) {
    console.error('Error fetching data from staking networks:', error)
    throw error
  }
}

// Function to get staked amount for a specific user
export async function getUserStakedAmount(userAddress: string): Promise<number> {
  try {
    const requests: Promise<any>[] = []
    Object.values(StakingInfo)
      .filter((info: any) => info.investmentContractAddress && info.investmentContractAddress !== '')
      .forEach((info: any) => {
        (info.tokens || []).forEach((token: TokenInfo) => {
          const request = new Promise((resolve, reject) => {
            // Function selector for getUserInvestedAmount(address)
            const functionSelector = '0x43214521'
            const paddedAddress = userAddress.replace('0x', '').padStart(64, '0')
            const data = functionSelector + paddedAddress
            
            fetch(info.RPC_URL, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                jsonrpc: '2.0',
                method: 'eth_call',
                params: [
                  {
                    to: info.investmentContractAddress,
                    data: data,
                  },
                  'latest',
                ],
                id: 1,
              }),
            })
              .then((response) => response.json())
              .then((data) => {
                resolve({
                  data: data,
                  token: token,
                })
              })
              .catch((error) => {
                reject(error)
              })
          })
          requests.push(request)
        })
      })
    
    const responses = await Promise.all(requests).catch((error) => {
      console.error('Error fetching user staked data:', error)
      throw error
    })

    const totalUserStakedAmount: number = responses.reduce(
      (
        acc: number,
        response: {
          data: any
          token: TokenInfo
        }
      ) => {
        // Defensive: skip if result is missing, not a string, or not a valid hex
        if (
          !response.data ||
          typeof response.data.result !== 'string' ||
          !/^0x[0-9a-fA-F]*$/.test(response.data.result) ||
          response.data.result === '0x'
        ) {
          return acc
        }
        const result = parseInt(response.data.result, 16)
        if (isNaN(result)) return acc
        const decimals = response.token.decimals
        const ethValue = parseFloat(
          ethers.formatUnits(result.toString(), decimals).toString()
        )
        return acc + ethValue
      },
      0
    )

    return parseFloat(totalUserStakedAmount.toString())
  } catch (error) {
    console.error('Error fetching user staked data:', error)
    throw error
  }
}