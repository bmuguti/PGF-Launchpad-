// Based on the AssetsConfig.json file, this function returns the contract address for the given network and the asset
import { AssetInfo } from '@/lib/types/investment-info'

export const getInvestmentInfoByNetwork = (network: number): AssetInfo | undefined => {
  const assetsConfig = require('@/lib/config/assets.json')
  return assetsConfig[network] as AssetInfo | undefined
}
