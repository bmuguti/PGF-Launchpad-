export const ROUTES = {
  STAKING: '/staking',
  LAUNCHPAD: '/',
  FAQS: '/faqs',
  PROJECT_DETAILS: '/project/:title',
}

export type Routes = keyof typeof ROUTES
