export const LOGO_URL =
  'https://www.labtoipo.com/images/Monotone-Logo-(Dark).png'
