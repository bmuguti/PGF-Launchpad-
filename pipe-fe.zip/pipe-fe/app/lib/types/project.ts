export interface Project {
  uid: string
  keywords: string[]
  status: ProjectStatuses
  reviews: number
  title: string
  seoTitle?: string
  abstract: string
  seoDescription?: string
  totalProgress: number
  image: string
}

type ProjectStatuses =
  | 'preparing'
  | 'disclosing'
  | 'being reviewed'
  | 'reporting'
  | 'triage'
