export type TokenInfo = {
  name: string
  address: string
  decimals: number
}

export type AssetInfo = {
  name: string
  tokens: TokenInfo[]
  investmentContractAddress: `0x${string}`
  RPC_URL: string
}

export type InvestmentInfoType = {
  [key: string]: AssetInfo
}
