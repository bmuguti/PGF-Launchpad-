export const getFAQs = async () => {
  return fetch('https://www.labtoipo.com/x/w3/faq/').then((response) => {
    return response.json()
  })
}

export const getProjects = async () => {
  return fetch('https://www.labtoipo.com/x/w3/').then((response) => {
    return response.json()
  })
}

export const getTargetRaise = async (): Promise<number> => {
  return fetch('https://www.labtoipo.com/x/w3/')
    .then((response) => {
      return response.json()
    })
    .then((res) => {
      return res.results.targetRaise
    })
}
