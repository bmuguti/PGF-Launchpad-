'use client'

import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { CustomWagmiProvider } from "@/lib/wagmi";
import { ThemeProvider } from "@/lib/contexts/theme";
import { CustomToastProvider } from "@/lib/components/custom-toast-provider";
import { ModalProvider } from "@/lib/contexts/modal";
import { Layout } from "@/lib/components/layout";
import dynamic from "next/dynamic";
import React from "react";
import { InvestModal } from '@/(routes)/(drawers)';

const FacebookPixelEvents = dynamic(
  () => import("@/lib/components/facebook-pixel"),
  { suspense: true },
);
const GoogleAnalytics = dynamic(
  () => import("@/lib/components/google-analytics"),
  { suspense: true },
);

export default function ClientProviders({ children, initialState }: { children: React.ReactNode, initialState: any }) {
  const [queryClient] = React.useState(() => new QueryClient())
  return (
    <QueryClientProvider client={queryClient}>
      <CustomWagmiProvider initialState={initialState}>
        <ThemeProvider>
          <CustomToastProvider />
          <ModalProvider>
            <Layout>
              {children}
              <InvestModal />
              <FacebookPixelEvents />
              <GoogleAnalytics />
            </Layout>
          </ModalProvider>
        </ThemeProvider>
      </CustomWagmiProvider>
    </QueryClientProvider>
  )
} 