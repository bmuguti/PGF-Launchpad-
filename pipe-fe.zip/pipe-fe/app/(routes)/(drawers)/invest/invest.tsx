'use client'

import { Dialog, Transition } from '@headlessui/react'
import { getBalance } from '@wagmi/core'
import { parseUnits } from 'ethers'
import Image from 'next/image'
import { Fragment, useEffect, useRef, useState } from 'react'
import ReCAPTCHA from 'react-google-recaptcha'
import { toast } from 'react-toastify'
import { useLocalStorage } from 'react-use'
import { twMerge } from 'tailwind-merge'
import { useAccount, useEnsName, useSwitchChain, useWriteContract } from 'wagmi'

import { WithdrawalAdvice } from '@/(routes)/(drawers)/invest/components/withdrawal-advice'
import InvestmentContractABI from '@/lib/assets/ABIs/investment-contract.json'
import USDCABI from '@/lib/assets/ABIs/usdc.json'
import { CoinsHandIcon } from '@/lib/assets/icons/coins-hand'
import { DollarIcon } from '@/lib/assets/icons/dollar'
import { InfoIcon } from '@/lib/assets/icons/info-icon'
import { WalletIconPlus } from '@/lib/assets/icons/wallet-icon-plus'
import { AssetSelectMenu } from '@/lib/components/asset-select-menu'
import { Button } from '@/lib/components/button'
import CustomFacebookPixelEvent from '@/lib/components/facebook-pixel/sendCustomPixelEvent'
import { LoadingSpinner } from '@/lib/components/loading-spinner'
import { NetworkSelectMenu } from '@/lib/components/network-select-menu'
import { Tag } from '@/lib/components/tag'
import { useModal } from '@/lib/contexts/modal'
import { calculateImageTranslation } from '@/lib/contexts/modal/helpers/calculateImageTranslation'
import { useTheme } from '@/lib/contexts/theme/useTheme'
import { getInvestmentInfoByNetwork } from '@/lib/helpers/getInvestmentInfoByNetwork'
import { useWindowSize } from '@/lib/hooks/useWindowSize'
import { Project } from '@/lib/types/project'
import { config as wagmiConfig } from '@/lib/wagmi/config'
import { TokenInfo } from '@/lib/types/investment-info'

import { NationalityAdvice } from './components/nationality-advice'
import { PrivacyAdvice } from './components/privacy-advice'
import { TermsAdvice } from './components/terms-advice'

export const InvestModal = () => {
  const { address, chainId } = useAccount()
  const { data: ensName } = useEnsName({
    address,
  })
  const recaptchaRef = useRef<ReCAPTCHA>(null)
  const [termsAccepted, setTermsAccepted] = useLocalStorage(
    'terms-advice',
    false
  )

  const [nationalityAdviceAccepted, setNationalityAdviceAccepted] =
    useLocalStorage('nationality-advice', false)

  const [privacyAdviceAccepted, setPrivacyAdviceAccepted] = useLocalStorage(
    'policy-advice',
    false
  )

  const [withdrawalAdviceAccepted, setWithdrawalAdviceAccepted] =
    useLocalStorage('withdrawal-advice', false)

  const [projects, setProjects] = useState<Project[]>([])
  const { isMobile } = useWindowSize()
  const [investment, setInvestment] = useState<string | null>(null)
  const [isInvesting, setIsInvesting] = useState(false)
  const [selectedNetwork, setSelectedNetwork] = useState<number>(42161)
  const { theme } = useTheme()
  const { closeModal, open } = useModal()
  const [selectedToken, setSelectedToken] = useState<string>('')
  const info = getInvestmentInfoByNetwork(selectedNetwork)
  const tokens: TokenInfo[] = info?.tokens || []

  useEffect(() => {
    if (!chainId) return
    
    // Check if the wallet's chain is supported for investment
    const chainInfo = getInvestmentInfoByNetwork(chainId)
    if (chainInfo) {
      setSelectedNetwork(chainId)
    } else {
      // Fallback to Arbitrum if current chain is not supported
      console.log(`Chain ${chainId} not supported for investment, defaulting to Arbitrum`)
      setSelectedNetwork(42161)
    }
  }, [chainId])


  const { writeContractAsync } = useWriteContract()
  const { writeContractAsync: writeTokenContract } = useWriteContract()

  const { switchChain } = useSwitchChain({
    mutation: {
      onError(error) {
        console.error(error)
        toast.error('Failed to switch chain.')
      },
      onSuccess() {
        handleInvestment()
      },
    },
  })

  useEffect(() => {
    fetch('/api/projects', {
      next: { revalidate: 300 },
    })
      .then((response) => response.json())
      .then((projects) => setProjects(projects))
  }, [])

  useEffect(() => {
    if (tokens.length > 0) {
      // If no token is selected or the current selectedToken is not in the new tokens, reset to first
      if (!selectedToken || !tokens.some(t => t.name === selectedToken)) {
        setSelectedToken(tokens[0].name)
      }
    }
  }, [selectedNetwork, tokens, selectedToken])

  const selectedTokenInfo = tokens.find((t) => t.name === selectedToken)

  const resetModalState = () => {
    setIsInvesting(false)
    recaptchaRef.current?.reset()
  }

  const handleInvestmentError = (err: any) => {
    console.log('HANDLING ERROR')
    console.error(err)
    if (!err || !err.message) return
    if (err.message.includes('Token is not allowed')) {
      toast.error('Investment contract does not allow this token.')
    } else if (err.message.includes('ERC20: transfer amount exceeds balance')) {
      toast.error(`You don't have enough ${selectedToken} to invest.`)
    } else if (
      err.message.includes('ERC20: transfer amount exceeds allowance')
    ) {
      toast.error('You have insufficient allowance to invest.')
    } else {
      toast.error(
        'Investment failed for an unknown reason. Check the console for more details.'
      )
    }
    return resetModalState()
  }
  const handleInvestment = async () => {
    // *********************
    // *  VALIDATE NETWORK  *
    // *********************

    if (!selectedNetwork) {
      return toast.error('Please select a network')
    }

    if (chainId !== selectedNetwork) {
      return switchChain({
        chainId: selectedNetwork,
      })
    }

    // *********************
    // *  VALIDATE FORM DATA  *
    // *********************

    if (isInvesting) {
      return toast.info('Transaction pending. Please wait.')
    } else if (!termsAccepted) {
      return toast.error('Please accept the terms and conditions')
    } else if (!nationalityAdviceAccepted) {
      return toast.error('Please accept the nationality advice')
    } else if (!privacyAdviceAccepted) {
      return toast.error('Please accept the privacy policy')
    } else if (!withdrawalAdviceAccepted) {
      return toast.error('Please accept the withdrawal policy')
    } else if (!investment) {
      return toast.error('Please enter an amount to invest')
    } else if (Number(investment) <= 0) {
      return toast.error('Please enter an amount greater than 0')
    } else if (!Number(investment)) {
      return toast.error('The amount is not a valid number')
    } else if (!address) {
      return toast.error('Please connect your wallet')
    }

    // *********************
    // *  VALIDATE BALANCE  *
    // *********************

    if (!selectedTokenInfo) {
      return toast.error('Invalid token selected.')
    }

    const balance = await getBalance(wagmiConfig, {
      address: address,
      token: selectedTokenInfo?.address as `0x${string}`,
      chainId: selectedNetwork,
    })

    if (parseUnits(investment, selectedTokenInfo?.decimals || 18) > balance.value) {
      console.log('balance', balance.value)
      console.log('investment', parseUnits(investment, selectedTokenInfo?.decimals || 18))
      resetModalState()
      return toast.error('Insufficient balance')
    }

    // *********************
    // *  WRITE CONTRACTS  *
    // *********************

    if (!selectedTokenInfo) {
      return toast.error('Invalid token selected.')
    }

    if (!info?.investmentContractAddress) {
      toast.error('Network not supported for investment')
      return resetModalState()
    }
    
    await writeTokenContract({
      address: selectedTokenInfo?.address as `0x${string}`,
      abi: USDCABI,
      functionName: 'increaseAllowance',
      args: [
        info.investmentContractAddress,
        parseUnits(investment, selectedTokenInfo?.decimals || 18),
      ],
    }).catch((err) => {
      console.error(err)
      toast.error('Approval failed')
      return resetModalState()
    })

    try {
      const hash = await writeContractAsync({
        address: info.investmentContractAddress,
        abi: InvestmentContractABI,
        functionName: 'invest',
        args: [selectedTokenInfo?.address, parseUnits(investment, selectedTokenInfo?.decimals || 18)],
        chainId: selectedNetwork,
      })
      console.log('Invest transaction hash: ', hash)
      return handleSuccessInvestment()
    } catch (err) {
      
      return handleInvestmentError(err)
    }
  }

  const handleSuccessInvestment = () => {
    toast.success('Investment successful')
    import('react-facebook-pixel')
      .then((x) => x.default)
      .then((ReactPixel) => {
        ReactPixel.trackCustom('InvestmentSuccessful', {
          value: investment,
          walletAddress: address,
        })
      })
    window.open(
      'https://blocksurvey.io/pipe-gdao-poc-platform-feedback-survey-2oyvSRIWSWWD_YxLvMLBEQ?v=o',
      '_blank'
    )
    // Close the modal
    closeModal()
    // Reset the investment amount
    setInvestment('')
    return resetModalState()
  }

  const images = projects.map((project) => ({
    src: project.image,
    alt: project.seoTitle,
  }))

  const imagesLength = images?.slice(0, 14).length ?? 0

  const translateX = calculateImageTranslation(imagesLength)

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-10" onClose={closeModal}>
        <Transition.Child
          as={Fragment}
          enter="ease-in-out duration-500"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in-out duration-500"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-[#626261] bg-opacity-75 transition-opacity" />
        </Transition.Child>
        <CustomFacebookPixelEvent
          eventName="ViewInvestDrawer"
          eventParams={{}}
        />

        <div className="fixed inset-0 overflow-hidden">
          <div className="absolute inset-0 overflow-hidden">
            <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full tablet:pl-10">
              <Transition.Child
                as={Fragment}
                enter="transform transition ease-in-out duration-500 sm:duration-700"
                enterFrom={isMobile ? 'translate-y-full' : 'translate-x-full'}
                enterTo={isMobile ? 'translate-y-[20%]' : 'translate-x-0'}
                leave="transform transition ease-in-out duration-500 sm:duration-700"
                leaveFrom={isMobile ? 'translate-y-[20%]' : 'translate-x-0'}
                leaveTo={isMobile ? 'translate-y-full' : 'translate-x-full'}
              >
                <Dialog.Panel className="pointer-events-auto w-screen tablet:max-w-[659px]">
                  <div
                    className="flex h-[80%] tablet:h-full flex-col overflow-y-scroll py-11 px-12 shadow-xl"
                    style={{
                      background:
                        theme === 'dark'
                          ? 'linear-gradient(292deg, rgba(89, 70, 40, 0.88) -131.47%, #25272C 55.27%)'
                          : '#F7F6F1',
                    }}
                  >
                    <Tag className="flex flex-row w-fit items-center">
                      <WalletIconPlus className="shrink-0" />
                      <span className="text-black dark:text-white font-bold text-[10px] overflow-hidden overflow-ellipsis">
                        {ensName ?? address}
                      </span>
                    </Tag>

                    {/* TODO: GROUP OF IMAGES */}
                    <div className="relative min-h-[224px] rounded-xl overflow-hidden w-full bg-gray-600 my-4">
                      {images?.slice(0, 14).map((image, index) => {
                        return (
                          <Image
                            key={image.alt}
                            src={image.src}
                            alt={image.alt ?? 'Project Image'}
                            width={240}
                            height={224}
                            className="absolute inset-0 w-[240px] h-[224px] object-cover rounded-lg z-10"
                            style={{
                              transform: `translateX(${translateX * index}px)`,
                              zIndex: index,
                            }}
                            onError={(e) =>
                              (e.currentTarget.style.display = 'none')
                            }
                          />
                        )
                      })}
                    </div>

                    <h1 className="text-black dark:text-white font-bold text-[25px] mt-7 py-3">
                      Invest in Project Basket
                    </h1>
                    <p className="text-[13px] font-normal text-black dark:text-white">
                      An investment basket allows for buying or selling a group
                      of assets in equal amounts at the same time. In this case
                      you are investing in basket of all the listed European
                      Union University real world impact projects listed below.
                    </p>

                    {/*<h2 className="text-[13px] font-bold text-black dark:text-white mt-8">
                      Projects
                    </h2>
                    <div className="flex flex-col gap-3 mt-3">
                      {projects.map((project) => (
                        <Tag
                          key={project.uid}
                          variant="outline"
                          className="flex flex-row items-center gap-x-2 py-1"
                        >
                          <TargetIcon className="shrink-0" />
                          <span className="text-[13px] text-[#F7F6F1] font-normal">
                            {project.seoTitle}
                          </span>
                        </Tag>
                      ))}
                    </div>*/}

                    <TermsAdvice
                      termsAccepted={termsAccepted ?? false}
                      setTermsAccepted={setTermsAccepted}
                    />

                    <NationalityAdvice
                      nationalityAdviceAccepted={
                        nationalityAdviceAccepted ?? false
                      }
                      setNationalityAdviceAccepted={
                        setNationalityAdviceAccepted
                      }
                    />

                    <PrivacyAdvice
                      privacyAdviceAccepted={privacyAdviceAccepted ?? false}
                      setPrivacyAdviceAccepted={setPrivacyAdviceAccepted}
                    />

                    <WithdrawalAdvice
                      withdrawalAdviceAccepted={
                        withdrawalAdviceAccepted ?? false
                      }
                      setWithdrawalAdviceAccepted={setWithdrawalAdviceAccepted}
                    />

                    <NetworkSelectMenu
                      onChange={setSelectedNetwork}
                      defaultValue={selectedNetwork}
                    />
                    <AssetSelectMenu
                      tokens={tokens}
                      selectedToken={selectedToken}
                      onChange={setSelectedToken}
                    />

                    <div className="flex flex-col tablet:flex-row gap-x-3 mt-[10px] items-center">
                      <div
                        className={twMerge(
                          'tablet:w-[251px] flex flex-row flex-grow items-center gap-x-2 border border-[#E0FF01] bg-black px-[7px] py-2 rounded-[6px] text-[20px] text-[#F7F6F1] font-bold',
                          isInvesting && 'opacity-70 cursor-not-allowed'
                        )}
                      >
                        <DollarIcon className="min-w-[24px]" />
                        <input
                          type="number"
                          placeholder="0.00"
                          className="bg-transparent w-full focus:outline-none focus:ring-0"
                          value={investment ?? ''}
                          disabled={isInvesting}
                          onChange={(e) => {
                            setInvestment(e.target.value)
                          }}
                        />
                      </div>
                      <Button
                        variant="dark"
                        className={twMerge(
                          'w-full tablet:w-[230px] mt-4 tablet:mt-0 border-none text-white',
                          isInvesting && 'opacity-70 cursor-not-allowed'
                        )}
                        disabled={isInvesting}
                        onClick={async () => {
                          await new Promise((resolve) =>
                            setTimeout(resolve, 1000)
                          )
                          handleInvestment()
                        }}
                      >
                        {isInvesting ? (
                          <LoadingSpinner className="mr-2 text-white" />
                        ) : (
                          <>
                            <CoinsHandIcon />
                            <span>Invest</span>
                          </>
                        )}
                      </Button>
                      {/* Info Icon */}
                      <InfoIcon
                        onClick={() => {
                          window.open(
                            'http://www.thepipegdao.io/blog/beta-test-the-future-of-impact-investing-with-the-pgf-web3-launchpad',
                            '_blank'
                          )
                        }}
                        className="w-[20px] h-[20px] mt-4 tablet:mt-0 text-black dark:text-white cursor-pointer"
                      />
                    </div>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  )
}
