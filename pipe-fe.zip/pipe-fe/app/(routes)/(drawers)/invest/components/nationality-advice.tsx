'use client'

import { Checkbox } from '@/lib/components/checkbox'

interface NationalityAdviceProps {
  nationalityAdviceAccepted: boolean
  // eslint-disable-next-line no-unused-vars
  setNationalityAdviceAccepted: (accepted: boolean) => void
}

export const NationalityAdvice = ({
  nationalityAdviceAccepted,
  setNationalityAdviceAccepted,
}: NationalityAdviceProps) => {
  return (
    <div className="flex flex-row gap-x-[6px] mt-10 items-center">
      <Checkbox
        id="nationality-advice"
        name="nationality-advice"
        onChange={() => {
          setNationalityAdviceAccepted(!nationalityAdviceAccepted)
        }}
        defaultChecked={nationalityAdviceAccepted}
      />

      <span className="text-[13px] font-normal text-black dark:text-white">
        I agree to the PIPE gDAO{' '}
        <a href="/nationality-disclaimer" className="font-bold underline">
          Nationality Advice
        </a>{' '}
      </span>
    </div>
  )
}
