'use client'

import { Checkbox } from '@/lib/components/checkbox'

interface PrivacyAdviceProps {
  privacyAdviceAccepted: boolean
  // eslint-disable-next-line no-unused-vars
  setPrivacyAdviceAccepted: (accepted: boolean) => void
}

export const PrivacyAdvice = ({
  privacyAdviceAccepted,
  setPrivacyAdviceAccepted,
}: PrivacyAdviceProps) => {
  return (
    <div className="flex flex-row gap-x-[6px] mt-10 items-center">
      <Checkbox
        id="privacy-advice"
        name="privacy-advice"
        onChange={() => {
          setPrivacyAdviceAccepted(!privacyAdviceAccepted)
        }}
        defaultChecked={privacyAdviceAccepted}
      />

      <span className="text-[13px] font-normal text-black dark:text-white">
        I agree to the PIPE gDAO{' '}
        <a href="/privacy-policy" className="font-bold underline">
          Privacy Policy
        </a>{' '}
      </span>
    </div>
  )
}
