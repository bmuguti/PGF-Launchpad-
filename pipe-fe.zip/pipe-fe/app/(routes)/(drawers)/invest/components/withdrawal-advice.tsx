'use client'

import { Checkbox } from '@/lib/components/checkbox'

interface WithdrawalAdviceProps {
  withdrawalAdviceAccepted: boolean
  // eslint-disable-next-line no-unused-vars
  setWithdrawalAdviceAccepted: (accepted: boolean) => void
}

export const WithdrawalAdvice = ({
  withdrawalAdviceAccepted,
  setWithdrawalAdviceAccepted,
}: WithdrawalAdviceProps) => {
  return (
    <div className="flex flex-row gap-x-[6px] mt-10 items-center">
      <Checkbox
        id="terms"
        name="terms"
        onChange={() => {
          setWithdrawalAdviceAccepted(!withdrawalAdviceAccepted)
        }}
        defaultChecked={withdrawalAdviceAccepted}
      />

      <span className="text-[13px] font-normal text-black dark:text-white">
        I agree to the PIPE gDAO{' '}
        <a href="/withdrawal-policy" className="font-bold underline">
          Withdrawal Policy
        </a>{' '}
      </span>
    </div>
  )
}
