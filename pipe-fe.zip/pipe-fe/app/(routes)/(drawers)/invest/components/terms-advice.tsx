'use client'

import { Checkbox } from '@/lib/components/checkbox'

interface TermsAdviceProps {
  termsAccepted: boolean
  // eslint-disable-next-line no-unused-vars
  setTermsAccepted: (accepted: boolean) => void
}

export const TermsAdvice = ({
  termsAccepted,
  setTermsAccepted,
}: TermsAdviceProps) => {
  return (
    <div className="flex flex-row gap-x-[6px] mt-10 items-center">
      <Checkbox
        id="terms"
        name="terms"
        onChange={() => {
          setTermsAccepted(!termsAccepted)
        }}
        defaultChecked={termsAccepted}
      />

      <span className="text-[13px] font-normal text-black dark:text-white">
        I agree to the PIPE gDAO{' '}
        <a href="/terms-and-conditions" className="font-bold underline">
          Terms and Conditions
        </a>{' '}
      </span>
    </div>
  )
}
