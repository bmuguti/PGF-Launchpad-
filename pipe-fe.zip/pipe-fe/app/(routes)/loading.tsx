import { LoadingSpinner } from '@/lib/components/loading-spinner'

export default function Loading() {
  return (
    <div className="flex items-center justify-center w-full h-full">
      <LoadingSpinner />
    </div>
  )
}
