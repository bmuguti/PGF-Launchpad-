/* eslint-disable react/no-unescaped-entities */
export default function DisclaimerPage() {
  return (
    <div className="space-y-6 dark:text-white">
      <h1>
        Nationality Disclaimer and Liability Restriction for Use of the PGF
        Launchpad Alpha
      </h1>
      <p>Last Updated: 16/04/2024</p>

      <h2 className="font-bold">1. Permitted Users by Nationality</h2>
      <p>
        Access to and use of the PGF Launchpad Alpha (the "Product"), managed by
        the PIPE gDAO (the "Company"), is expressly permitted only to
        individuals who are residents of, and physically located within, the
        following countries at the time of use:
        <ol>
          <li>- Argentina</li>
          <li>- Austria</li>
          <li>- Belgium</li>
          <li>- Brazil</li>
          <li>- Bulgaria</li>
          <li>- Canada</li>
          <li>- Chile</li>
          <li>- Colombia</li>
          <li>- Cyprus</li>
          <li>- Czech Republic</li>
          <li>- Denmark</li>
          <li>- Estonia</li>
          <li>- Finland</li>
          <li>- France</li>
          <li>- Germany</li>
          <li>- Greece</li>
          <li>- Hungary</li>
          <li>- India</li>
          <li>- Ireland</li>
          <li>- Israel</li>
          <li>- Italy</li>
          <li>- Japan</li>
          <li>- Kazakhstan</li>
          <li>- Latvia</li>
          <li>- Liechtenstein</li>
          <li>- Lithuania</li>
          <li>- Luxembourg</li>
          <li>- Malta</li>
          <li>- Mauritius</li>
          <li>- Mexico</li>
          <li>- Netherlands</li>
          <li>- Norway</li>
          <li>- Poland</li>
          <li>- Portugal</li>
          <li>- Romania</li>
          <li>- Seychelles</li>
          <li>- Singapore</li>
          <li>- Slovakia</li>
          <li>- Slovenia</li>
          <li>- South Korea</li>
          <li>- Spain</li>
          <li>- Sweden</li>
          <li>- Switzerland</li>
          <li>- Taiwan</li>
          <li>- Thailand</li>
          <li>- United Arab Emirates</li>
          <li>- United Kingdom</li>
          <li>- China</li>
        </ol>
      </p>

      <h2 className="font-bold">Restricted Users by Nationality</h2>
      <p>
        Access to and use of the Product is explicitly prohibited for residents
        of the United States and any countries not listed above. Individuals
        from the United States or from countries not included in the list above
        are not authorized to use the Product and must not attempt to register
        an account or use any services provided by the Product.
      </p>

      <h2 className="font-bold">3. Legal Liability Disclaimer</h2>
      <p>
        The Company disclaims any legal liability, whether civil or criminal,
        for actions taken by individuals or entities using the Product from
        restricted jurisdictions. By using the Product, users from restricted
        jurisdictions agree to indemnify and hold the Company harmless against
        any claims, losses, liabilities, or expenses arising from their breach
        of these Terms.
      </p>

      <h2 className="font-bold">4. Platform Jurisdiction</h2>
      <p>
        The Product operates under the legal jurisdictions of the United Kingdom
        and the European Union. It complies with all applicable laws and
        regulations in these regions. Users must comply with local laws in their
        jurisdiction, which must also be one of the approved countries listed
        above.
      </p>

      <h2 className="font-bold">5. Compliance Obligation</h2>
      <p>
        It is the responsibility of all users to ensure that their use of the
        Product complies with all local laws and regulations of their respective
        jurisdictions, including but not limited to those related to online
        platforms and financial services. Users must verify their eligibility
        based on residency and geographical location before using the Product.
      </p>
      <h2 className="font-bold">6. Violation of Terms</h2>
      <p>
        Any use of the Product by persons from restricted countries, including
        the United States, constitutes a violation of these Terms and may lead
        to immediate termination of access to the Product, revocation of any
        transactions or memberships, and further legal action.
      </p>
      <h2 className="font-bold">7. Acknowledgement of Terms</h2>
      <p>
        Your continued use of the Product signifies your explicit understanding
        of and agreement to this Nationality Disclaimer and Liability
        Restriction, and all other terms and conditions as stipulated in the
        Terms of Service of the Product.
      </p>

      <p>
        For any queries or further information regarding the nationality
        restrictions, liability disclaimers, or any other aspects of these
        Terms, please contact the Company at{' '}
        <a href="mailto:info@thepipegdao.io" className="text-blue-500">
          info@thepipegdao.io
        </a>
        .
      </p>
    </div>
  )
}
