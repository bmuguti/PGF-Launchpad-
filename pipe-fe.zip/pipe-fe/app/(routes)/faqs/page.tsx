import './index.css'

import { Metadata } from 'next'

import { LOGO_URL } from '@/lib/constants'

import AnimatedFAQContent from './animated-faq-content'

export const metadata: Metadata = {
  title: 'The PIPE gDAO Frequently Asked Questions',
  description:
    'Your knowledge base for everything you need to know about the PIPE General Fund Launchpad DAO and the PIPE Platform. Join our discord community for more knowledge.',
  applicationName: 'PIPE',
  robots: 'index, follow',
  twitter: {
    images: [
      {
        url: LOGO_URL,
        width: 800,
        height: 600,
        alt: 'The PIPE gDAO Frequently Asked Questions',
      },
    ],
    description:
      'Your knowledge base for everything you need to know about the PIPE General Fund Launchpad DAO and the PIPE Platform. Join our discord community for more knowledge.',
    card: 'summary_large_image',
    title: 'The PIPE gDAO Frequently Asked Questions',
  },
  openGraph: {
    images: [
      {
        url: LOGO_URL,
        width: 800,
        height: 600,
        alt: 'The PIPE gDAO Frequently Asked Questions',
      },
    ],
  },
  // metadataBase:
  //   process.env.NODE_ENV === 'production'
  //     ? new URL('https://www.yourdomain.com')
  //     : new URL('http://localhost:3000'),
}

export const dynamic = 'force-dynamic'

export default function Page({
  searchParams: { category: selectedCategory },
}: {
  searchParams: { category: string }
}) {
  return <AnimatedFAQContent selectedCategory={selectedCategory} />
}
