'use client'

import { motion } from 'framer-motion'
import { Suspense } from 'react'

import { MagicWandIcon } from '@/lib/assets/icons/magic-wand'
import { Divider } from '@/lib/components/divider'
import CustomFacebookPixelEvent from '@/lib/components/facebook-pixel/sendCustomPixelEvent'
import { LoadingSpinner } from '@/lib/components/loading-spinner'
import PageOverview from '@/lib/components/page-overview'

import Questions from './questions'

interface AnimatedFAQContentProps {
  selectedCategory: string
}

export default function AnimatedFAQContent({ selectedCategory }: AnimatedFAQContentProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <CustomFacebookPixelEvent eventName="ViewFAQs" eventParams={{}} />
      <PageOverview />
      <Divider />
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <motion.div 
          className="flex flex-row items-center justify-center tablet:justify-start gap-x-[10px]"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <div className="p-[7px] bg-black rounded-[20px]">
            <MagicWandIcon />
          </div>
          <h1 className="text-xl font-bold text-black dark:text-white">
            {"FAQ'S"}
          </h1>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <Suspense
            fallback={
              <div className="w-full flex justify-center mt-10">
                <LoadingSpinner />
              </div>
            }
          >
            <Questions selectedCategory={selectedCategory} />
          </Suspense>
        </motion.div>
      </motion.section>
    </motion.div>
  )
} 