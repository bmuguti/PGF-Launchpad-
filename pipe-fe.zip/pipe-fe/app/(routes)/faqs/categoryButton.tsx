'use client'

import Link from 'next/link'
import { twMerge } from 'tailwind-merge'

export default function CategoryButton({
  category,
  selectedCategory,
}: {
  category: string
  selectedCategory: string
}) {
  return (
    <Link href={`?category=${category}`}>
      <span
        className={twMerge(
          'text-[#9F9D9C] dark:text-[#9F9D9C]',
          selectedCategory === category
            ? 'text-black dark:text-white font-bold'
            : 'cursor-pointer'
        )}
      >
        {category}
      </span>
    </Link>
  )
}
