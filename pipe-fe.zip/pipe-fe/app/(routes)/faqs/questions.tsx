import { Divider } from '@/lib/components/divider'
import { getFAQs } from '@/lib/services/api'
import { FAQ } from '@/lib/types/faqs'

import CategoryButton from './categoryButton'
async function loader() {
  const { results } = await getFAQs()

  const categories = Object.keys(results.FAQ)
  const questions: FAQ[] = []

  categories.forEach((category) => {
    const faqs = results.FAQ[category]
    Object.keys(faqs).forEach((faqId) => {
      const faq = faqs[faqId]
      questions.push({
        id: faqId,
        question: faq.Q,
        answer: faq.A,
        category: category,
      })
    })
  })

  return { questions, categories }
}

export default async function Questions({
  selectedCategory,
}: {
  selectedCategory: string
}) {
  const { questions, categories } = await loader()

  const filteredQuestions = questions.filter(
    (question) => !selectedCategory || question.category === selectedCategory
  )

  return (
    <>
      <div className="mt-[18px] flex flex-row flex-wrap gap-[14px]">
        {categories.map((category, index) => (
          <CategoryButton
            key={category + index}
            category={category}
            selectedCategory={selectedCategory}
          />
        ))}
      </div>
      <div className="mt-6">
        {filteredQuestions.map((question) => {
          const formattedAnswer = question.answer.replace(/\r\n/g, '<br>')

          return (
            <div key={question.id}>
              <div className="mt-6">
                <h1 className="text-lg my-3 font-bold text-black dark:text-white">
                  {question.question}
                </h1>
                <p
                  // Make a tags be blue
                  className="answer-container mt-3 text-[#9F9D9C] dark:text-[#9F9D9C]"
                  dangerouslySetInnerHTML={{
                    __html: formattedAnswer,
                  }}
                ></p>
              </div>
              <Divider className="mt-7" />
            </div>
          )
        })}
      </div>
    </>
  )
}
