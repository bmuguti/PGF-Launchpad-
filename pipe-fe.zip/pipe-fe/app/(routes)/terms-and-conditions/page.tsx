/* eslint-disable react/no-unescaped-entities */
export default async function Page() {
  return (
    <div className="space-y-6 dark:text-white">
      <h1>Terms and Conditions</h1>

      <h2 className="font-bold">1. Acceptance of Terms</h2>
      <p>
        By using the services provided by the PGF Launchpad Alpha (the
        "Product"), managed by the PIPE gDAO (the "Company"), you agree to these
        Terms and Conditions (the "Terms"). If you do not agree with these
        Terms, you must not use the Product.
      </p>

      <h2 className="font-bold">2. Description of the Service</h2>
      <p>
        The Product is a multi-chain decentralized application (dApp) available
        on various Ethereum Virtual Machine (EVM) compatible blockchains,
        including Arbitrum, Binance Smart Chain (BSC), Avalanche, Polygon, Base,
        Optimism, Ethereum, and Blast Network. This platform is a
        membership-based, alpha minimum viable product (MVP) designed to
        demonstrate first principles with end users and is not a final,
        market-ready product. Memberships are issued as "soulbound" NFTs at the
        point of first deposit on a member's wallet, meaning they cannot be
        transferred or traded. These memberships are utilized to access
        potential capital gains, which are considered rewards and not
        investments. These rewards are subject to performance and are not
        guaranteed.
      </p>

      <h2 className="font-bold">3. Nature of Transactions</h2>
      <p>
        Membership investments in the Product do not constitute the sale or
        exchange of any assets or cryptocurrencies. Instead, memberships are
        intended to provide access to potential capital gains as rewards,
        contingent upon the acquisition of a project on the PIPE exchange, which
        is under development. These transactions should not be viewed as
        financial investments in assets, equities, or cryptocurrencies.
      </p>

      <h2 className="font-bold">4. Supported Cryptocurrencies</h2>
      <p>
        The Product accepts USDC stablecoin on Arbitrum, BSC, Avalanche,
        Polygon, Base, Optimism, Ethereum networks, and USDB on the Blast
        Network. Members are required to use these specified cryptocurrencies
        for all deposits and transactions on the respective networks.
      </p>

      <h2 className="font-bold">5. Activation of Membership Rewards</h2>
      <p>
        To activate membership rewards, users must verify ownership of their
        soulbound NFT through the designated verification process on our Discord
        channel. Details and instructions for the verification process are
        provided on the Discord channel. Failure to complete verification may
        result in the inability to access certain features or rewards offered by
        the Product.
      </p>

      <h2 className="font-bold">6. Blockchain and Smart Contracts</h2>
      <p>
        The Product is fully automated by smart contracts and operates on
        permissionless public blockchain networks. The Company does not control
        or oversee the Product's operations, nor can it control access to the
        Product. Access removal can only occur by "burning" a member’s NFT if
        they are found in breach of these Terms or applicable laws.
      </p>

      <h2 className="font-bold">7. Fees and Payments</h2>
      <p>
        The Company charges a 10% fee on all deposits made to the Product, known
        as the "levy penny." This fee is used to cover operational expenses,
        further develop the ecosystem of the Product, and generate profits where
        appropriate. Members are responsible for paying any network fees
        associated with the blockchain networks used for their transactions.
      </p>

      <h2 className="font-bold">8. Compliance with Laws</h2>
      <p>
        Members must comply with all applicable anti-money laundering (AML)
        laws, financial regulations, and other legal requirements in their local
        jurisdictions, as well as those in the UK and the EU where the Company
        operates. The Product adheres to the General Data Protection Regulation
        (GDPR) to protect personal data and privacy of EU citizens. Members are
        informed of their rights under GDPR, including rights to access,
        rectify, and erase personal data, through our Privacy Policy.
      </p>

      <h2 className="font-bold">9. Risks Acknowledgment</h2>

      <p>
        Members acknowledge and accept the risks associated with using
        blockchain technology and smart contracts, as well as the specific risks
        related to the supported stablecoins (USDC and USDB). These risks
        include, but are not limited to:
        <ol>
          <li>
            - Stablecoin Volatility: Although stablecoins are designed to be
            stable, they may still be subject to market fluctuations and
            potential de-pegging from their underlying assets.
          </li>
          <li>
            - Counterparty Risks: Risks related to the management and solvency
            of the entities issuing the stablecoins.
          </li>
          <li>
            - Regulatory Risks: The legal landscape for stablecoins is still
            evolving, which could lead to impactful regulatory changes.
          </li>
          <li>
            - Technical Failures: The possibility of encountering system
            failures, programming errors, or security vulnerabilities.
          </li>
          <li>
            - Market Volatility: Substantial fluctuations in the price of
            cryptocurrencies that could impact the value of your digital assets.
          </li>
          <li>
            - Regulatory Changes: Potential legal changes in the regulatory
            framework governing blockchain technologies and cryptocurrencies,
            which could affect the operation of the Product.
          </li>
          <li>
            - Operational Risks: Risks associated with the decentralized nature
            of blockchain technologies, which may lead to irreversible
            transactions or loss of funds.
          </li>
        </ol>
      </p>

      <h2 className="font-bold">10. No Warranty</h2>
      <p>
        The services provided by the Product are on an "as is" and "as
        available" basis. The Company makes no representations or warranties of
        any kind, whether express or implied, as to the operation of their
        services or the information, content, materials, or products included on
        the Product.
      </p>

      <h2 className="font-bold">11. Limitation of Liability</h2>
      <p>
        The Company shall not be liable for any damages of any kind arising from
        the use of the Product, including, but not limited to direct, indirect,
        incidental, punitive, and consequential damages, to the fullest extent
        permissible by law.
      </p>

      <h2 className="font-bold">12. Dispute Resolution</h2>
      <p>
        Disputes arising under these Terms will be resolved through an effective
        dispute resolution process, detailed in our Dispute Resolution Policy,
        which includes mediation and arbitration procedures.
      </p>

      <h2 className="font-bold">13. Changes to the Terms</h2>
      <p>
        These Terms are subject to change by the Company at any time. We will
        notify you of any changes by posting the new Terms on the platform. Your
        continued use of the services after any changes constitutes your
        acceptance of the new Terms.
      </p>

      <h2 className="font-bold">14. Contact Information</h2>
      <p>
        If you have any concerns or questions about these Terms, please contact
        us at [info@thepipegdao.io].
      </p>
    </div>
  )
}
