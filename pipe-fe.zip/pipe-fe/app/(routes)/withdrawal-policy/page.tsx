/* eslint-disable react/no-unescaped-entities */
export default async function Page() {
  return (
    <div className="space-y-6 dark:text-white">
      <h1>PGF Launchpad Alpha Withdrawal Policy</h1>

      <h2 className="font-bold">1. Introduction</h2>
      <p>
        This Withdrawal Policy ("Policy") governs the withdrawal of digital
        assets deposited into the contracts facilitated by the PGF Launchpad
        Alpha ("Company"). By depositing assets into our contracts via your web3
        wallet, you agree to this Policy, which forms part of the broader terms
        governing your use of our services.
      </p>

      <h2 className="font-bold">2. User Eligibility</h2>
      <p>
        No registration is required to participate. Users must access our
        services using a compatible web3 wallet. Users are responsible for
        securing their wallet and managing their private keys.
      </p>

      <h2 className="font-bold">3. Deposit Lock-Up</h2>
      <p>
        All funds deposited are subject to a lock-up period that supports the
        stability and security of the projects launched via our platform. This
        period ensures that projects have sufficient time to progress and meet
        predefined milestones.
      </p>

      <h2 className="font-bold">4. Withdrawal Terms</h2>
      <ol>
        <li>
          - Initial Lock-Up Period: Deposited funds are locked for six (6)
          months from the date of deposit. Withdrawals are not permitted during
          this period.
        </li>
        <li>
          - First Withdrawal Window: Post the initial six-month period, users
          are eligible to withdraw up to fifty percent (50%) of their originally
          deposited funds.
        </li>
        <li>
          - Second Withdrawal Window: The remaining balance can be withdrawn
          after twelve (12) months from the date of initial deposit.
        </li>
      </ol>

      <h2 className="font-bold">5. Process of Withdrawal</h2>
      <ol>
        <li>
          - Request: Withdrawal requests must be initiated directly through the
          user’s web3 wallet interface connected to our platform. Users must
          follow the on-screen instructions to start the withdrawal process.
        </li>
        <li>
          - Timing: Withdrawal requests are typically processed on the
          blockchain within minutes, but timing may vary based on network
          congestion and the specific blockchain used.
        </li>
        <li>
          - Fees: The Company does not charge any fees for withdrawals. However,
          users are responsible for any network fees charged by the blockchain,
          which are required to execute the transactions.
        </li>
      </ol>

      <h2 className="font-bold">6. Security and Risks</h2>
      <p>
        The security of your funds is primarily dependent on the protections
        offered by the underlying blockchain and your own security practices,
        including safeguarding your wallet keys. The Company is not responsible
        for losses that occur as a result of compromised user security or the
        inherent risks associated with blockchain technologies.
      </p>

      <h2 className="font-bold">7. Legal Compliance</h2>
      <p>
        The platform operates on a permissionless blockchain and facilitates
        transactions in accordance with the rules of that blockchain. Users are
        responsible for ensuring that their transactions comply with the laws
        and regulations applicable in their jurisdiction.
      </p>

      <h2 className="font-bold">8. Amendments to the Withdrawal Policy</h2>
      <p>
        We reserve the right to amend this Policy at any time. Amendments will
        take effect immediately upon their announcement on the platform.
        Continued use of the platform after any amendments constitutes
        acceptance of the new Policy.
      </p>

      <h2 className="font-bold">9. Contact Information</h2>
      <p>
        For technical support or policy questions, please contact our support
        team through {''}
        <a href="mailto:support@thepipegdao.io" className="text-blue-500">
          info@thepipegdao.io
        </a>
        .
      </p>
      <p className="my-4">---</p>
      <p>
        This version of the policy has been simplified to better align with the
        decentralized and non-custodial nature of the platform. It also removes
        references to identity verification and withdrawal fees, reflecting the
        permissionless and fee-free structure of the platform. Again, it would
        be wise to have this policy reviewed by a legal expert to ensure full
        compliance and adequacy for the intended jurisdictions.
      </p>
    </div>
  )
}
