'use client'

import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import { toast } from 'react-toastify'
import { useAccount, useWriteContract, useReadContract, useSwitchChain } from 'wagmi'
import { parseUnits, formatUnits } from 'ethers'
import { getBalance } from '@wagmi/core'

import { MagicWandIcon } from '@/lib/assets/icons/magic-wand'
import { WalletIcon } from '@/lib/assets/icons/wallet-icon'
import { Button } from '@/lib/components/button'
import { Divider } from '@/lib/components/divider'
import CustomFacebookPixelEvent from '@/lib/components/facebook-pixel/sendCustomPixelEvent'
import { LoadingSpinner } from '@/lib/components/loading-spinner'
import { SpotlightCard } from '@/lib/components/spotlight-card'
import { config as wagmiConfig } from '@/lib/wagmi/config'
import { getStakingInfoByNetwork } from '@/lib/helpers/getStakingInfoByNetwork'
import InvestmentContractABI from '@/lib/assets/ABIs/investment-contract.json'
import USDCABI from '@/lib/assets/ABIs/usdc.json'

const L1X_CHAIN_ID = 1066

export default function StakingPage() {
  const { address, isConnected, chainId } = useAccount()
  const [stakeAmount, setStakeAmount] = useState<string>('')
  const [stakedAmount, setStakedAmount] = useState<number>(0)
  const [gdaoBalance, setGdaoBalance] = useState<number>(0)
  const [l1xBalance, setL1xBalance] = useState<number>(0)
  const [isStaking, setIsStaking] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  
  const { writeContractAsync } = useWriteContract()
  const { writeContractAsync: writeTokenContract } = useWriteContract()
  
  const { switchChain } = useSwitchChain({
    mutation: {
      onError(error) {
        console.error('Chain switch error:', error)
        toast.error('Failed to switch to L1X network.')
        setIsStaking(false)
      },
      onSuccess() {
        toast.success('Switched to L1X network')
        // Retry staking after successful chain switch
        handleStakeAfterChainSwitch()
      },
    },
  })
  
  const stakingInfo = getStakingInfoByNetwork(L1X_CHAIN_ID)
  const tokenInfo = stakingInfo?.tokens[0] // sGDAO token
  
  // Read staked amount from contract
  const { data: contractStakedAmount, refetch: refetchStakedAmount } = useReadContract({
    address: stakingInfo?.investmentContractAddress,
    abi: InvestmentContractABI,
    functionName: 'getUserInvestedAmount',
    args: [address],
    chainId: L1X_CHAIN_ID,
    query: {
      enabled: !!address && isConnected && !!stakingInfo?.investmentContractAddress,
    },
  })

  // Update staked amount from contract
  useEffect(() => {
    if (contractStakedAmount && tokenInfo) {
      setStakedAmount(parseFloat(contractStakedAmount.toString()) / Math.pow(10, tokenInfo.decimals))
    }
  }, [contractStakedAmount, tokenInfo])

  // Fetch user's GDAO balance and L1X native balance
  useEffect(() => {
    if (!address || !isConnected) {
      setIsLoading(false)
      return
    }

    const fetchUserData = async () => {
      try {
        // Fetch sGDAO balance
        if (!tokenInfo) return
        
        const balance = await getBalance(wagmiConfig, {
          address: address,
          token: tokenInfo.address as `0x${string}`,
          chainId: L1X_CHAIN_ID,
        })
        setGdaoBalance(parseFloat(formatUnits(balance.value, balance.decimals)))

        // Fetch L1X native balance
        const l1xNativeBalance = await getBalance(wagmiConfig, {
          address: address,
          chainId: L1X_CHAIN_ID,
        })
        setL1xBalance(parseFloat(formatUnits(l1xNativeBalance.value, l1xNativeBalance.decimals)))
      } catch (error) {
        console.error('Error fetching user data:', error)
        toast.error('Failed to fetch user data')
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserData()
  }, [address, isConnected, tokenInfo])
  
  // Refetch data when wallet reconnects or chain changes
  useEffect(() => {
    if (address && isConnected && tokenInfo) {
      refetchStakedAmount()
      fetchUserData()
    }
  }, [address, isConnected, chainId, tokenInfo, refetchStakedAmount])

  const handleStakingError = (err: any) => {
    console.error('Staking error:', err)
    if (!err || !err.message) return
    
    if (err.message.includes('Token is not allowed')) {
      toast.error('Staking contract does not allow this token.')
    } else if (err.message.includes('ERC20: transfer amount exceeds balance')) {
      toast.error(`You don't have enough sGDAO to stake.`)
    } else if (err.message.includes('ERC20: transfer amount exceeds allowance')) {
      toast.error('You have insufficient allowance to stake.')
    } else {
      toast.error('Staking failed for an unknown reason. Check the console for more details.')
    }
    setIsStaking(false)
  }

  const handleStake = async () => {
    if (!address || !isConnected) {
      toast.error('Please connect your wallet')
      return
    }

    if (chainId !== L1X_CHAIN_ID) {
      toast.info('Switching to L1X network...')
      return switchChain({ chainId: L1X_CHAIN_ID })
    }
    
    await performStaking()
  }
  
  const handleStakeAfterChainSwitch = async () => {
    await performStaking()
  }
  
  const performStaking = async () => {
    if (!tokenInfo || !stakingInfo) {
      toast.error('Staking configuration not available')
      return
    }

    if (!stakeAmount || parseFloat(stakeAmount) <= 0) {
      toast.error('Please enter a valid amount')
      return
    }

    if (parseFloat(stakeAmount) > gdaoBalance) {
      toast.error('Insufficient sGDAO balance')
      return
    }

    if (isStaking) {
      toast.info('Staking transaction in progress...')
      return
    }
    
    setIsStaking(true)

    try {
      // First, increase allowance for the staking contract
      try {
        await writeTokenContract({
          address: tokenInfo.address as `0x${string}`,
          abi: USDCABI,
          functionName: 'increaseAllowance',
          args: [
            stakingInfo.investmentContractAddress,
            parseUnits(stakeAmount, tokenInfo.decimals),
          ],
          chainId: L1X_CHAIN_ID,
        })
      } catch (err) {
        console.error('Allowance failed:', err)
        toast.error('Token approval failed. Please try again.')
        setIsStaking(false)
        throw err
      }
      
      toast.info('Approval successful, processing stake...')

      // Then call invest function on the staking contract
      const hash = await writeContractAsync({
        address: stakingInfo.investmentContractAddress,
        abi: InvestmentContractABI,
        functionName: 'invest',
        args: [tokenInfo.address, parseUnits(stakeAmount, tokenInfo.decimals)],
        chainId: L1X_CHAIN_ID,
      })

      toast.success('Staking successful! Transaction confirmed.')
      console.log('Stake transaction hash:', hash)
      
      // Reset form
      setStakeAmount('')
      
      // Immediately refresh staked amount and balance
      await refetchStakedAmount()
      await fetchUserData()
      
      // Also refetch after a short delay to ensure blockchain state is updated
      setTimeout(async () => {
        await refetchStakedAmount()
        await fetchUserData()
      }, 3000)
      
    } catch (error) {
      handleStakingError(error)
    } finally {
      setIsStaking(false)
    }
  }
  
  const fetchUserData = async () => {
    if (!address || !isConnected || !tokenInfo) return
    
    try {
      const balance = await getBalance(wagmiConfig, {
        address: address,
        token: tokenInfo.address as `0x${string}`,
        chainId: L1X_CHAIN_ID,
      })
      setGdaoBalance(parseFloat(formatUnits(balance.value, balance.decimals)))

      // Fetch L1X native balance
      const l1xNativeBalance = await getBalance(wagmiConfig, {
        address: address,
        chainId: L1X_CHAIN_ID,
      })
      setL1xBalance(parseFloat(formatUnits(l1xNativeBalance.value, l1xNativeBalance.decimals)))
    } catch (error) {
      console.error('Error fetching user data:', error)
    }
  }

  const truncateAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <CustomFacebookPixelEvent eventName="ViewStaking" eventParams={{}} />
      {/* User Info Section */}
      <motion.section 
        className="mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
      >
        <motion.div 
          className="flex flex-row items-center justify-center tablet:justify-start gap-x-[10px] mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <div className="p-[7px] bg-black rounded-[20px]">
            <WalletIcon />
          </div>
          <h2 className="text-xl font-bold text-black dark:text-white">
            Your Wallet
          </h2>
        </motion.div>

        {!isConnected ? (
          <div className="text-center py-8">
            <p className="text-[#9F9D9C] dark:text-[#9F9D9C] mb-4">Please connect your wallet to view staking information</p>
          </div>
        ) : isLoading ? (
          <div className="flex justify-center py-8">
            <LoadingSpinner />
          </div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 tablet:grid-cols-2 desktop:grid-cols-4 gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            {/* Wallet Address */}
            <motion.div 
              className="bg-white dark:bg-[#24272C] rounded-[20px] p-6 border border-[#EAE7E7] dark:border-[#30343A]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              <h3 className="text-sm font-bold text-black dark:text-white mb-2">Wallet Address</h3>
              <p className="text-[#9F9D9C] dark:text-[#9F9D9C] font-mono text-sm">{truncateAddress(address!)}</p>
            </motion.div>

            {/* Staked Amount */}
            <motion.div 
              className="bg-white dark:bg-[#24272C] rounded-[20px] p-6 border border-[#EAE7E7] dark:border-[#30343A]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.5 }}
            >
              <h3 className="text-sm font-bold text-black dark:text-white mb-2">Staked Amount</h3>
              <p className="text-[31px] font-bold text-black dark:text-white">{stakedAmount.toFixed(2)} sGDAO</p>
            </motion.div>

            {/* Available Balance */}
            <motion.div 
              className="bg-white dark:bg-[#24272C] rounded-[20px] p-6 border border-[#EAE7E7] dark:border-[#30343A]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.5 }}
            >
              <h3 className="text-sm font-bold text-black dark:text-white mb-2">Available Balance</h3>
              <p className="text-[31px] font-bold text-black dark:text-white">{gdaoBalance.toFixed(2)} sGDAO</p>
            </motion.div>

            {/* L1X Native Balance */}
            <motion.div 
              className="bg-white dark:bg-[#24272C] rounded-[20px] p-6 border border-[#EAE7E7] dark:border-[#30343A]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.5 }}
            >
              <h3 className="text-sm font-bold text-black dark:text-white mb-2">L1X Native Balance</h3>
              <p className="text-[31px] font-bold text-black dark:text-white">{l1xBalance.toFixed(4)} L1X</p>
            </motion.div>
          </motion.div>
        )}
      </motion.section>

      <Divider className="my-8" />

      <div className="grid grid-cols-1 desktop:grid-cols-2 gap-8">
        {/* Staking Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.6 }}
        >
          <motion.div 
            className="flex flex-row items-center justify-center tablet:justify-start gap-x-[10px] mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0, duration: 0.6 }}
          >
            <div className="p-[7px] bg-black rounded-[20px]">
              <MagicWandIcon />
            </div>
            <h2 className="text-xl font-bold text-black dark:text-white">
              Stake sGDAO Tokens
            </h2>
          </motion.div>

          {!isConnected ? (
            <div className="text-center py-8">
              <p className="text-[#9F9D9C] dark:text-[#9F9D9C] mb-4">Connect your wallet to start staking</p>
            </div>
          ) : (
            <motion.div 
              className="max-w-md mx-auto tablet:mx-0"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.1, duration: 0.6 }}
            >
              <div className="bg-white dark:bg-[#24272C] rounded-[20px] p-6 border border-[#EAE7E7] dark:border-[#30343A]">
                <div className="mb-4">
                  <label htmlFor="stake-amount" className="block text-sm font-medium text-black dark:text-white mb-2">
                    Amount to Stake
                  </label>
                  <div className="relative">
                    <input
                      id="stake-amount"
                      type="number"
                      value={stakeAmount}
                      onChange={(e) => setStakeAmount(e.target.value)}
                      placeholder="Enter amount"
                      className="w-full px-4 py-3 border border-[#EAE7E7] dark:border-[#30343A] rounded-md bg-transparent text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-[#24272C] dark:focus:ring-white"
                      disabled={isStaking}
                    />
                    <div className="absolute right-3 top-3 text-[#9F9D9C] dark:text-[#9F9D9C] text-sm">
                      sGDAO
                    </div>
                  </div>
                  <div className="mt-2 text-xs text-[#9F9D9C] dark:text-[#9F9D9C]">
                    Available: {gdaoBalance.toFixed(2)} sGDAO
                  </div>
                </div>

                <Button
                  variant="dark"
                  className="w-full"
                  onClick={handleStake}
                  disabled={isStaking || !stakeAmount || parseFloat(stakeAmount) <= 0}
                >
                  {isStaking ? (
                    <>
                      <LoadingSpinner className="mr-2 text-white" />
                      <span>Staking...</span>
                    </>
                  ) : (
                    <span>Stake sGDAO</span>
                  )}
                </Button>

                <div className="mt-4 text-xs text-[#9F9D9C] dark:text-[#9F9D9C] text-center">
                  Tokens will be staked via investment contract: {stakingInfo?.investmentContractAddress?.slice(0, 6)}...{stakingInfo?.investmentContractAddress?.slice(-4)}
                </div>
              </div>
            </motion.div>
          )}
        </motion.section>

        {/* L1X Faucet Promotional Card */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.6 }}
        >
          <SpotlightCard
            className="bg-gradient-to-br from-gray-50 via-gray-100 to-gray-200 dark:from-gray-800 dark:via-gray-900 dark:to-black rounded-[20px] p-8 border border-[#EAE7E7] dark:border-[#30343A]"
            spotlightColor="rgba(0, 0, 0, 0.05)"
          >
            <div className="relative z-10">
              <div className="flex items-center justify-center w-16 h-16 mx-auto mb-6 bg-black dark:bg-white rounded-full">
                <svg className="w-8 h-8 text-white dark:text-black" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
              </div>
              
              <h3 className="text-2xl font-bold text-center text-black dark:text-white mb-4">
                Get L1X Tokens for Free!
              </h3>
              
              <p className="text-center text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                Need L1X tokens for transactions? Get them instantly from our faucet. 
                No cost, no hassle - just free tokens to get you started on the L1X network.
              </p>
              
              <div className="flex justify-center">
                <a
                  href="https://faucet.l1xapp.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-6 py-3 bg-black dark:bg-white text-white dark:text-black font-semibold rounded-lg transition-colors duration-200 shadow-lg hover:shadow-xl hover:bg-gray-800 dark:hover:bg-gray-100"
                >
                  <span className="mr-2">🚰</span>
                  Access L1X Faucet
                  <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                </a>
              </div>
              
              <div className="mt-4 text-center text-xs text-gray-500 dark:text-gray-400">
                External link opens in new tab
              </div>
            </div>
          </SpotlightCard>
        </motion.section>
      </div>
    </motion.div>
  )
} 