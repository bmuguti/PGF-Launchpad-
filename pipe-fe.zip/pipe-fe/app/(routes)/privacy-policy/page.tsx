/* eslint-disable react/no-unescaped-entities */
export default function PrivacyPolicyPage() {
  return (
    <div className="space-y-6 dark:text-white">
      <h1>Privacy Policy</h1>
      <p>Last Updated: 16/04/2024</p>

      <h2 className="font-bold">1. Introduction</h2>
      <p>
        This Privacy Policy applies to all personal data processed by the PGF
        Launchpad Alpha, managed by the PIPE gDAO ("Company"), through its
        multi-chain decentralized application (dApp) and associated services
        (collectively, the "Product"). By using the Product, you agree to the
        terms of this Privacy Policy. If you disagree with any part of this
        policy, please do not use the Product.
      </p>

      <h2 className="font-bold">2. Data Collection</h2>
      <p>
        The Product collects personal information necessary to provide our
        services, including but not limited to:
        <ol>
          <li>
            - Identity Data: such as your name, username or similar identifier.
          </li>
          <li>
            - Contact Data: including email address and telephone numbers.
          </li>
          <li>
            - Transaction Data: details about transactions you carry out through
            our Product, including the blockchain addresses used.
          </li>
          <li>
            - Technical Data: includes internet protocol (IP) address, your
            login data, and other technology on the devices you use to access
            the Product.
          </li>
        </ol>
      </p>

      <h2 className="font-bold">3. Use of Data</h2>
      <p>
        The data collected is used to:
        <br />
        Provide Services: to manage your access to our services and to perform
        the contract between you and us.
        <br />
        Verify Identity: verify your identity as part of our security and
        verification procedures.
        <br />
        Compliance and Regulations: to comply with legal obligations and
        regulatory requirements, including anti-money laundering (AML) laws.
        <br />
        Communication: to inform you about changes to our terms or privacy
        policy, and to send you service-related communications.
      </p>

      <h2 className="font-bold">4. Data Sharing</h2>
      <p>
        We may share your data with:
        <ol>
          <li>
            - Service Providers: including IT and system administration
            providers.
          </li>
          <li>
            - Regulatory Authorities: when required by law or to protect our
            legal rights.
          </li>
          <li>
            - Affiliates and Partners: companies that may have products or
            services we believe interest you. We only share your data for
            marketing purposes with your consent and you will have the
            opportunity to opt out of such sharing.
          </li>
          <li>
            - Third Parties for Marketing: We may share your data with third
            parties to offer you targeted marketing of products and services
            that may be of interest. Your personal data will never be sold, and
            you can withdraw your consent to this sharing at any time.
          </li>
        </ol>
      </p>

      <h2 className="font-bold">5. Data Security</h2>
      <p>
        We implement appropriate security measures to protect against
        unauthorized access, alteration, disclosure, or destruction of your
        personal data. Our security procedures include, among others, firewalls,
        encryption, and secure software development practices.
      </p>

      <h2 className="font-bold">6. Data Retention</h2>
      <p>
        We will retain your personal data only for as long as is necessary for
        the purposes set out in this Privacy Policy, and to comply with our
        legal obligations (for example, if we are required to retain your data
        to comply with applicable laws), resolve disputes, and enforce our legal
        agreements and policies.
      </p>

      <h2 className="font-bold">7. Your Rights</h2>
      <p>
        Under certain circumstances, you have rights under data protection laws
        in relation to your personal data. These rights include:
        <br />
        Right to Access: You have the right to request access to your personal
        data.
        <br />
        Right to Correction: You have the right to request correction of the
        personal data that we hold about you.
        <br />
        Right to Erasure: You have the right to request erasure of your personal
        data.
        <br />
        Right to Object: You have the right to object to processing your
        personal data.
        <br />
        Right to Withdraw Consent: Where the lawful basis for processing is
        consent, you have the right to withdraw consent at any time.
      </p>

      <h2 className="font-bold">8. International Transfers</h2>
      <p>
        Your information, including personal data, may be transferred to — and
        maintained on — computers located outside of your state, province,
        country, or other governmental jurisdiction where the data protection
        laws may differ from those of your jurisdiction. We will take all the
        steps reasonably necessary to ensure that your data is treated securely
        and in accordance with this Privacy Policy.
      </p>

      <h2 className="font-bold">9. Changes to this Privacy Policy</h2>
      <p>
        We may update our Privacy Policy from time to time. We will notify you
        of any changes by posting the new Privacy Policy on this page. You are
        advised to review this Privacy Policy periodically for any changes.
      </p>

      <h2 className="font-bold">10. Contact Us</h2>
      <p>
        For any questions or requests regarding this Privacy Policy, please
        contact us using the contact information provided in the Terms and
        Conditions.
      </p>
    </div>
  )
}
