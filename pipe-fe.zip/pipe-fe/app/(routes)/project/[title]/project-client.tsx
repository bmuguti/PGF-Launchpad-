'use client'

import { motion } from 'framer-motion'
import Image from 'next/image'
import { useEffect, useState } from 'react'

import { MagicWandIcon } from '@/lib/assets/icons/magic-wand'
import { Button } from '@/lib/components/button'
import { Divider } from '@/lib/components/divider'
import CustomFacebookPixelEvent from '@/lib/components/facebook-pixel/sendCustomPixelEvent'
import { Tag } from '@/lib/components/tag'
import { Timeline } from '@/lib/components/timeline/timeline'
import { Project } from '@/lib/types/project'

interface ProjectClientProps {
  project: Project
}

export default function ProjectClient({ project }: ProjectClientProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <CustomFacebookPixelEvent
        eventName={'ViewProjectDetails'}
        eventParams={{
          projectId: project.uid,
        }}
      />
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
      >
        <Button variant="back" />
      </motion.div>
      <motion.div 
        className="mt-7 flex flex-row justify-between items-center"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <div className="flex flex-col pt-3 tablet:pr-5">
          <h1 className="text-[31px] font-bold text-center tablet:text-start text-black dark:text-white">
            {project.title}
          </h1>
          <motion.div 
            className="flex flex-row flex-wrap mt-6 gap-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            {project.keywords.map((tag, index) => (
              <motion.div
                key={tag}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 + index * 0.1, duration: 0.3 }}
              >
                <Tag>
                  <span>{tag}</span>
                </Tag>
              </motion.div>
            ))}
          </motion.div>
          <motion.div 
            className="flex flex-col gap-y-[14px] mt-[30px] w-full tablet:hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
          >
            <Button variant="getInvolved" className="w-full" />
            <Button variant="invest" className="w-full" />
          </motion.div>
        </div>
        <motion.div 
          className="hidden tablet:flex flex-col gap-y-[14px] self-end"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <Button variant="invest" className="w-[251px]" />
          <Button className="w-[251px]" variant="getInvolved" />
        </motion.div>
      </motion.div>
      <Divider className="my-8" />
      <motion.p 
        className="text-justify text-black dark:text-white"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.6 }}
      >
        {project.seoDescription}
      </motion.p>
      <motion.div 
        className="flex items-center justify-center tablet:justify-start"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.6 }}
      >
        <Image
          src={project.image}
          width={240}
          height={224}
          alt="project image"
          className="mt-11"
        />
      </motion.div>
      <Divider className="my-8" />
      <motion.div 
        className="flex flex-row items-center gap-x-[10px]"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, duration: 0.6 }}
      >
        <div className="p-[7px] bg-black rounded-[20px]">
          <MagicWandIcon />
        </div>
        <h1 className="text-xl font-bold text-black dark:text-white">
          Project Details
        </h1>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0, duration: 0.6 }}
      >
        <Timeline
          className="mt-6 tablet:w-[80%]"
          progress={project.totalProgress}
        />
      </motion.div>
      <motion.div 
        className="space-y-[10px] mb-[144px] text-black dark:text-white"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.1, duration: 0.6 }}
      >
        <p className="mt-[38px]">{project.abstract}</p>
      </motion.div>
    </motion.div>
  )
}