import type { Metadata } from 'next'
import { redirect } from 'next/navigation'

import { ROUTES } from '@/lib/constants/routes'
import { normalizeTitleForURL } from '@/lib/helpers/normalizeTitleForURL'
import { getProjects } from '@/lib/services/api'
import { Project } from '@/lib/types/project'
import ProjectClient from './project-client'

export async function generateMetadata({
  params: { title },
}: {
  params: { title: string }
}): Promise<Metadata> {
  const { project } = await loader(title)

  return {
    title: project.seoTitle,
    description: project.seoDescription,
    applicationName: 'PIPE',
    robots: 'index, follow',
    keywords: project.keywords,
    // metadataBase:
    //   process.env.NODE_ENV === 'production'
    //     ? new URL('https://www.yourdomain.com')
    //     : new URL('http://localhost:3000'),
    twitter: {
      images: [
        {
          url: project.image,
          width: 800,
          height: 600,
          alt: project.seoTitle,
        },
      ],
      description: project.seoDescription,
      card: 'summary_large_image',
      title: project.seoTitle,
    },
    openGraph: {
      images: [
        {
          url: project.image,
          width: 800,
          height: 600,
          alt: project.seoTitle,
        },
      ],
    },
  }
}

export const dynamic = 'force-dynamic'

async function loader(title: string) {
  if (!title) {
    return redirect(ROUTES.LAUNCHPAD)
  }
  const res = await getProjects()
  const projects = res.results.disclosures as Project[]
  if (!projects) {
    return redirect(ROUTES.LAUNCHPAD)
  }
  // If not seoTitle available, use uid as fallback
  const project = projects.find(
    (project) =>
      (project.seoTitle && normalizeTitleForURL(project.seoTitle) === title) ||
      project.uid === title
  )

  if (!project) {
    return redirect(ROUTES.LAUNCHPAD)
  }

  return { project }
}

export default async function Page({
  params: { title },
}: {
  params: { title: string }
}) {
  const { project } = await loader(title)

  return <ProjectClient project={project} />
}
