'use client'

import { motion } from 'framer-motion'
import { useEffect, useState } from 'react'

import { MagicWandIcon } from '@/lib/assets/icons/magic-wand'
import { Divider } from '@/lib/components/divider'
import CustomFacebookPixelEvent from '@/lib/components/facebook-pixel/sendCustomPixelEvent'
import PageOverview from '@/lib/components/page-overview'
import { ProjectCard } from '@/lib/components/project-card/project-card'
import { getProjects } from '@/lib/services/api'
import { Project } from '@/lib/types/project'

async function loader(): Promise<{
  projects: Project[]
}> {
  const res = await getProjects()
  const order = res['results']['seq']['disclosure']['age'] as number[]
  const projects = res.results.disclosures as Project[]

  // order is an array of projectIDs, so the same order of the IDs should be the returned ID
  const sortedProjects = projects
    .sort(
      (a, b) => order.indexOf(parseInt(a.uid)) - order.indexOf(parseInt(b.uid))
    )
    .reverse()

  return { projects: sortedProjects }
}

export const dynamic = 'force-dynamic'

export default function Page() {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadProjects = async () => {
      try {
        const { projects } = await loader()
        setProjects(projects)
      } catch (error) {
        console.error('Error loading projects:', error)
      } finally {
        setLoading(false)
      }
    }
    loadProjects()
  }, [])

  const validProjects = projects.filter((project) => project.uid)

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex items-center justify-center min-h-[200px]"
      >
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-black dark:border-white"></div>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <CustomFacebookPixelEvent eventName="ViewMainPage" eventParams={{}} />
      <PageOverview />
      <Divider />
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <motion.div 
          className="flex flex-row items-center justify-center tablet:justify-start gap-x-[10px]"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <div className="p-[7px] bg-black rounded-[20px]">
            <MagicWandIcon />
          </div>
          <h1 className="text-xl font-bold text-black dark:text-white">
            Available Projects
          </h1>
        </motion.div>
        {validProjects.length === 0 ? (
          <motion.div 
            className="flex flex-row justify-center items-center mt-10 text-black dark:text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
          >
            No projects available
          </motion.div>
        ) : (
          <div className="mt-9 space-y-[14px]">
            {projects.map((project: Project, index: number) => (
              <motion.div
                key={project.uid}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.1, duration: 0.5 }}
              >
                <ProjectCard project={project} />
              </motion.div>
            ))}
          </div>
        )}
      </motion.section>
    </motion.div>
  )
}
