import "./globals.css";
import "react-toastify/dist/ReactToastify.css";
import "@/lib/assets/font-awesome/css/brands.min.css";
import "@/lib/assets/font-awesome/css/fontawesome.min.css";
import "@/lib/assets/font-awesome/css/regular.min.css";
import "@/lib/assets/font-awesome/css/solid.min.css";

import { Metadata } from "next";
import { Inter } from "next/font/google";
import { headers } from "next/headers";
import React from "react";
import { cookieToInitialState } from "wagmi";
import { config } from "@/lib/wagmi/config";
import ClientProviders from "@/lib/ClientProviders";
import { LOGO_URL } from "@/lib/constants";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
	title: "PGF Launchpad Alpha",
	description:
		"Discover the PGF Launchpad, connecting EU university lab innovations with retail investors through blockchain. Unlock new investment opportunities in university IP and real-world assets today.",
	applicationName: "PIPE",
	robots: "index, follow",
	twitter: {
		images: [
			{
				url: LOGO_URL,
				width: 800,
				height: 600,
				alt: "PGF Launchpad Alpha",
			},
		],
		description:
			"Discover the PGF Launchpad, connecting EU university lab innovations with retail investors through blockchain. Unlock new investment opportunities in university IP and real-world assets today.",
		card: "summary_large_image",
		title: "PGF Launchpad Alpha",
	},
	openGraph: {
		images: [
			{
				url: LOGO_URL,
				width: 800,
				height: 600,
				alt: "PGF Launchpad Alpha",
			},
		],
	},
	// metadataBase:
	//   process.env.NODE_ENV === 'production'
	//     ? new URL('https://www.yourdomain.com')
	//     : new URL('http://localhost:3000'),
};

export default function RootLayout({
	children,
}: {
	children: React.ReactNode;
}) {
	let initialState;
	try {
		initialState = cookieToInitialState(config, headers().get("cookie"));
	} catch (error) {
		console.error("Error parsing wagmi cookie state:", error);
		initialState = undefined;
	}
	
	return (
		<html lang="en">
			<body className={inter.className}>
				<ClientProviders initialState={initialState}>
					{children}
				</ClientProviders>
			</body>
		</html>
	);
}
