import { Project } from '@/lib/types/project'

export async function GET() {
  const rawResponse = await fetch('https://www.labtoipo.com/x/w3/', {
    cache: 'no-cache',
    headers: {
      'Cache-Control': 's-maxage=300',
    },
  })
  const res = await rawResponse.json()
  const rawProjects = res.results.disclosures as Project[]
  const projects = rawProjects.filter((project) => project.uid)
  return Response.json(projects)
}
