export async function POST(request: Request) {
  const params = await request.json()

  try {
    if (!params.captchaToken) {
      return Response.json({ success: false })
    }
    const response = await fetch(
      `https://www.google.com/recaptcha/api/siteverify?secret=${process.env.RECAPTCHA_SECRET_KEY}&response=${params.captchaToken}`,
      {
        method: 'POST',
        // headers: {
        //   'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8',
        // },
      }
    )
    if (response.ok) {
      const data = await response.json()
      if (data.success) {
        // reCAPTCHA verification succeeded
        return Response.json({ success: true })
      } else {
        // reCAPTCHA verification failed
        return Response.json({ success: false })
      }
    } else {
      return Response.json({ success: false })
    }
  } catch (error) {
    console.error(error)
    return Response.json({ success: false })
  }
}
