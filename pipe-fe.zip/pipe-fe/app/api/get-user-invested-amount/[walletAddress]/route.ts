import { ethers } from 'ethers'

import InvestmentInfo from '@/lib/config/assets.json'
// Use a compatible type for AssetInfo import
import { AssetInfo, TokenInfo } from '@/lib/types/investment-info'

const getRequestBody = (contractAddress: string, walletAddress: string) => {
  return {
    jsonrpc: '2.0',
    method: 'eth_call',
    params: [
      {
        to: contractAddress,
        // Function selector with parameters
        data: '0xcc178180' + walletAddress,
      },
      'latest',
    ],
    id: 1,
  }
}

export async function GET(
  _: Request,
  { params }: { params: { walletAddress: string } }
) {
  try {
    const paddedAddress = params.walletAddress
      .replace('0x', '')
      .padStart(64, '0')

    const requests: any[] = []
    Object.values(InvestmentInfo)
      .filter((info: any) => info.investmentContractAddress && info.investmentContractAddress !== '')
      .forEach((info: any) => {
        (info.tokens || []).forEach((token: TokenInfo) => {
          const request = new Promise((resolve, reject) => {
            fetch(info.RPC_URL, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(
                getRequestBody(info.investmentContractAddress, paddedAddress)
              ),
            })
              .then((response) => response.json())
              .then((data) => {
                resolve({
                  data: data,
                  token: token,
                })
              })
              .catch((error) => {
                reject(error)
              })
          })
          requests.push(request)
        })
      })
    const responses = await Promise.all(requests).catch((error) => {
      console.error('Error fetching data from networks:', error)
      throw error
    })

    const userInvestedAmount: number = responses.reduce(
      (
        acc: number,
        response: {
          data: any
          token: TokenInfo
        }
      ) => {
        if (response.data.result == '0x') return acc
        const result = parseInt(response.data.result, 16)
        const decimals = response.token.decimals
        const ethValue = parseFloat(
          ethers.formatUnits(result.toString(), decimals).toString()
        )
        return acc + ethValue
      },
      0
    )

    return Response.json({
      success: true,
      message: 'Successfully retrieved user invested amount',
      data: { userInvestedAmount },
    })
  } catch (error) {
    console.error('Error fetching data from networks:', error)
    throw error
  }
}
