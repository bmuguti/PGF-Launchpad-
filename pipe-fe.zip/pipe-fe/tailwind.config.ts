import type { Config } from 'tailwindcss'
import defaultTheme from 'tailwindcss/defaultTheme'
const config: Config = {
  darkMode: 'class',
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  purge: ['./app/**/*.{js,jsx,ts,tsx}'],
  theme: {
    fontFamily: {
      sans: ['Inter', ...defaultTheme.fontFamily.sans],
      jakarta: ['Plus Jakarta Sans', ...defaultTheme.fontFamily.sans],
    },
    screens: {
      tablet: '768px',
      desktop: '1440px',
    },
    extend: {
      colors: {
        black: {
          DEFAULT: '#212427',
        },
      },
    },
  },
  plugins: [],
}
export default config
